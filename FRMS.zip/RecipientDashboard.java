package registration;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Recipient screen (FR2, FR4, FR5, FR6). Only opens for a logged-in RECIPIENT session (NFR3),
 * so recipients never see donor metrics and donors never reach the claim screen.
 */
public class RecipientDashboard extends JFrame {

    private static final String[] TIME_FILTER_LABELS = {"Any time", "Within 1 hour", "Within 3 hours",
            "Within 6 hours", "Within 12 hours", "Within 24 hours"};
    private static final int[] TIME_FILTER_HOURS = {0, 1, 3, 6, 12, 24};

    private final int userId;
    private UserDAO.Profile profile;

    // browse & claim
    private DefaultTableModel browseModel;
    private JTable browseTable;
    private JComboBox<String> typeFilterBox, timeFilterBox;
    private JTextField donorFilterField, foodNameFilterField;
    private JCheckBox cityOnlyBox;
    private JLabel browseStatusLabel, welcomeLabel;

    // pickups waiting for the donor's OTP check
    private DefaultTableModel pickupModel;
    private JTable pickupTable;
    private JLabel pickupStatusLabel;

    // requirements
    private DefaultTableModel requestModel;
    private JTable requestTable;
    private JComboBox<String> reqTypeBox, reqUrgencyBox;
    private JTextField reqNameField, reqServingsField;
    private JButton reqSubmitButton, reqCancelEditButton;
    private JLabel reqFormTitle;
    private int editingRequestId = -1;

    // profile
    private DefaultTableModel claimsModel;
    private JLabel instLabel, idLabel, phoneLabel, addressLabel, cityLabel, capacityLabel;

    private javax.swing.Timer countdownTimer;

    public RecipientDashboard() {
        UiUtil.installTheme();
        userId = Session.getUserId();
        if (!Session.hasRole(Session.RECIPIENT)) {      // session / role guard
            UiUtil.showWarn(null, "Please log in as a Recipient to open this dashboard.");
            dispose();
            new LoginForm();
            return;
        }

        setTitle("Recipient Dashboard - Food Redistribution Management");
        setSize(1180, 760);
        setMinimumSize(new Dimension(1040, 640));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        welcomeLabel = new JLabel("Welcome, " + nameOrDefault(Session.getInstitution()));
        JButton headerLogout = UiUtil.onHeader("Log Out");
        headerLogout.addActionListener(e -> logout());
        add(UiUtil.appHeader(welcomeLabel, "Find food, collect it, and confirm with your OTP", "RECIPIENT PORTAL", headerLogout),
                BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Browse & Claim Food", buildBrowseTab());
        tabs.addTab("My Pickups", buildPickupsTab());
        tabs.addTab("My Food Requirements", buildRequirementsTab());
        tabs.addTab("Recipient Profile", buildProfileTab());
        add(tabs, BorderLayout.CENTER);

        refreshAll();

        countdownTimer = new javax.swing.Timer(1000, e -> tickCountdown());
        countdownTimer.start();
        setVisible(true);
    }

    // =================================================================== UI
    private JPanel buildBrowseTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 12));
        panel.setBorder(BorderFactory.createEmptyBorder(18, 22, 12, 22));

        // ---- filters (FR5): food type, donor name, time left before expiry, local network
        typeFilterBox = new JComboBox<>(prepend("All types", UiUtil.FOOD_TYPES));
        foodNameFilterField = new JTextField(11);
        donorFilterField = new JTextField(12);
        timeFilterBox = new JComboBox<>(TIME_FILTER_LABELS);
        cityOnlyBox = new JCheckBox("My city only", true);
        cityOnlyBox.setOpaque(false);
        JButton search = UiUtil.primary("Search");
        JButton reset = UiUtil.secondary("Reset");
        search.addActionListener(e -> refreshBrowseOnly());
        reset.addActionListener(e -> {
            typeFilterBox.setSelectedIndex(0);
            foodNameFilterField.setText("");
            donorFilterField.setText("");
            timeFilterBox.setSelectedIndex(0);
            cityOnlyBox.setSelected(true);
            refreshBrowseOnly();
        });
        foodNameFilterField.addActionListener(e -> refreshBrowseOnly());
        donorFilterField.addActionListener(e -> refreshBrowseOnly());

        UiUtil.Card filters = new UiUtil.Card(new FlowLayout(FlowLayout.LEFT, 14, 0));
        filters.setBorder(BorderFactory.createEmptyBorder(12, 16, 14, 16));
        filters.add(labelled("Food name", foodNameFilterField));
        filters.add(labelled("Food type", typeFilterBox));
        filters.add(labelled("Donor name", donorFilterField));
        filters.add(labelled("Expiry", timeFilterBox));
        filters.add(labelled(" ", cityOnlyBox));
        filters.add(labelled(" ", search));
        filters.add(labelled(" ", reset));
        panel.add(filters, BorderLayout.NORTH);

        browseModel = UiUtil.readOnlyModel("Listing ID", "Donor", "Address", "City", "Food Name", "Food Type",
                "Quantity", "Unit", "Expires At", "Time Left");
        browseTable = new JTable(browseModel);
        UiUtil.styleTable(browseTable, 32);
        browseTable.getColumnModel().getColumn(8).setCellRenderer(UiUtil.TIMESTAMP_RENDERER);
        panel.add(new JScrollPane(browseTable), BorderLayout.CENTER);

        JButton refresh = UiUtil.secondary("Refresh");
        JButton claim = UiUtil.primary("Accept Selected Listing");
        claim.setFont(UiUtil.font(Font.BOLD, 14f));
        refresh.addActionListener(e -> refreshBrowseOnly());
        claim.addActionListener(e -> claimSelected());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttons.add(refresh);
        buttons.add(claim);
        browseStatusLabel = UiUtil.statusLine();
        JPanel south = new JPanel(new BorderLayout());
        south.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));
        south.add(browseStatusLabel, BorderLayout.WEST);
        south.add(buttons, BorderLayout.EAST);
        panel.add(south, BorderLayout.SOUTH);
        return panel;
    }

    /** Accepted listings that are waiting for the recipient to arrive; the OTP is shown here. */
    private JPanel buildPickupsTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(18, 22, 12, 22));

        JPanel head = new JPanel(new GridLayout(2, 1, 0, 2));
        head.add(UiUtil.sectionTitle("Pickups waiting for you (status: PENDING)"));
        JLabel hint = UiUtil.statusLine();
        hint.setText("Go to the donor's address and tell them your OTP. The food counts as claimed only after the donor enters it.");
        head.add(hint);
        panel.add(head, BorderLayout.NORTH);

        pickupModel = UiUtil.readOnlyModel("Listing ID", "Donor", "Address", "City", "Phone", "Food Name",
                "Quantity", "Unit", "Pickup OTP", "Collect Before");
        pickupTable = new JTable(pickupModel);
        UiUtil.styleTable(pickupTable, 32);
        pickupTable.getColumnModel().getColumn(9).setCellRenderer(UiUtil.TIMESTAMP_RENDERER);
        panel.add(new JScrollPane(pickupTable), BorderLayout.CENTER);

        JButton refresh = UiUtil.secondary("Refresh");
        JButton cancel = UiUtil.danger("Cancel Pickup");
        refresh.addActionListener(e -> refreshAll());
        cancel.addActionListener(e -> cancelSelectedPickup());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttons.add(refresh);
        buttons.add(cancel);
        pickupStatusLabel = UiUtil.statusLine();
        JPanel south = new JPanel(new BorderLayout());
        south.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));
        south.add(pickupStatusLabel, BorderLayout.WEST);
        south.add(buttons, BorderLayout.EAST);
        panel.add(south, BorderLayout.SOUTH);
        return panel;
    }

    /** Small caption above a control, used by the filter bar. */
    private static JPanel labelled(String caption, JComponent comp) {
        JPanel box = new JPanel(new BorderLayout(0, 4));
        box.setOpaque(false);
        box.add(UiUtil.fieldLabel(caption), BorderLayout.NORTH);
        box.add(comp, BorderLayout.CENTER);
        return box;
    }

    private JPanel buildRequirementsTab() {
        JPanel panel = new JPanel(new BorderLayout(18, 0));
        panel.setBorder(BorderFactory.createEmptyBorder(18, 22, 16, 22));

        // ---- form (create + edit share the same fields)
        reqNameField = new JTextField();
        reqTypeBox = new JComboBox<>(UiUtil.FOOD_TYPES);
        reqServingsField = new JTextField();
        reqUrgencyBox = new JComboBox<>(UiUtil.URGENCY_LEVELS);
        reqUrgencyBox.setSelectedItem("MEDIUM");

        reqFormTitle = UiUtil.sectionTitle("New requirement");
        JPanel fields = UiUtil.form(
                new String[]{"Food name needed", "Food type needed", "Servings needed", "Urgency"},
                new JComponent[]{reqNameField, reqTypeBox, reqServingsField, reqUrgencyBox});

        reqSubmitButton = UiUtil.primary("Publish Requirement");
        reqSubmitButton.setFont(UiUtil.font(Font.BOLD, 14f));
        reqCancelEditButton = UiUtil.secondary("Cancel Edit");
        reqCancelEditButton.setVisible(false);
        reqSubmitButton.addActionListener(e -> submitRequirement());
        reqCancelEditButton.addActionListener(e -> resetRequirementForm());

        JPanel formButtons = new JPanel(new GridLayout(0, 1, 0, 8));
        formButtons.setOpaque(false);
        formButtons.add(reqSubmitButton);
        formButtons.add(reqCancelEditButton);

        UiUtil.Card formCard = new UiUtil.Card(new BorderLayout(0, 14));
        formCard.setBorder(BorderFactory.createEmptyBorder(18, 22, 20, 22));
        JPanel head = new JPanel(new GridLayout(2, 1, 0, 2));
        head.setOpaque(false);
        head.add(reqFormTitle);
        JLabel hint = UiUtil.statusLine();
        hint.setText("Log a food shortage so donors can see it.");
        head.add(hint);
        formCard.add(head, BorderLayout.NORTH);
        formCard.add(fields, BorderLayout.CENTER);
        formCard.add(formButtons, BorderLayout.SOUTH);

        JPanel formWrap = new JPanel(new BorderLayout());
        formWrap.setOpaque(false);
        formWrap.setPreferredSize(new Dimension(360, 100));
        formWrap.add(formCard, BorderLayout.NORTH);
        panel.add(formWrap, BorderLayout.WEST);

        // ---- table
        requestModel = UiUtil.readOnlyModel("Req ID", "Food Name", "Food Type", "Servings", "Urgency", "Status", "Posted");
        requestTable = new JTable(requestModel);
        UiUtil.styleTable(requestTable, 32);
        requestTable.getColumnModel().getColumn(6).setCellRenderer(UiUtil.TIMESTAMP_RENDERER);

        JButton edit = UiUtil.primary("Edit Selected");
        JButton delete = UiUtil.danger("Delete Selected");
        edit.addActionListener(e -> startEditRequirement());
        delete.addActionListener(e -> deleteSelectedRequirement());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttons.add(edit);
        buttons.add(delete);

        JPanel center = new JPanel(new BorderLayout(5, 10));
        center.add(UiUtil.sectionTitle("My food requirements"), BorderLayout.NORTH);
        center.add(new JScrollPane(requestTable), BorderLayout.CENTER);
        JPanel south = new JPanel(new BorderLayout());
        south.setBorder(BorderFactory.createEmptyBorder(6, 0, 0, 0));
        south.add(buttons, BorderLayout.EAST);
        center.add(south, BorderLayout.SOUTH);
        panel.add(center, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildProfileTab() {
        JPanel panel = new JPanel(new BorderLayout(0, 16));
        panel.setBorder(BorderFactory.createEmptyBorder(18, 22, 16, 22));

        instLabel = new JLabel();
        idLabel = new JLabel();
        phoneLabel = new JLabel();
        addressLabel = new JLabel();
        cityLabel = new JLabel();
        capacityLabel = new JLabel();
        instLabel.setFont(UiUtil.font(Font.BOLD, 17f));
        instLabel.setForeground(UiUtil.ORANGE_DARK);
        JPanel lines = new JPanel(new GridLayout(0, 2, 20, 6));
        lines.setOpaque(false);
        for (JLabel l : new JLabel[]{idLabel, phoneLabel, cityLabel, capacityLabel, addressLabel}) {
            l.setFont(UiUtil.font(Font.PLAIN, 13f));
            lines.add(l);
        }
        JButton editProfile = UiUtil.primary("Edit Profile / Capacity");
        editProfile.addActionListener(e -> {
            if (ProfileDialog.edit(this, userId, true)) {
                refreshAll();
                UiUtil.showInfo(this, "Profile updated.");
            }
        });

        UiUtil.Card card = new UiUtil.Card(new BorderLayout(0, 10), UiUtil.ORANGE);
        card.setBorder(BorderFactory.createEmptyBorder(16, 24, 16, 20));
        JLabel cap = UiUtil.statusLine();
        cap.setText("RECIPIENT PROFILE");
        JPanel nameBox = new JPanel(new GridLayout(2, 1, 0, 2));
        nameBox.setOpaque(false);
        nameBox.add(cap);
        nameBox.add(instLabel);
        JPanel cardTop = new JPanel(new BorderLayout(10, 0));
        cardTop.setOpaque(false);
        cardTop.add(nameBox, BorderLayout.CENTER);
        cardTop.add(editProfile, BorderLayout.EAST);
        card.add(cardTop, BorderLayout.NORTH);
        card.add(lines, BorderLayout.CENTER);
        panel.add(card, BorderLayout.NORTH);

        claimsModel = UiUtil.readOnlyModel("Listing ID", "Donor", "Food Name", "Food Type", "Quantity", "Unit", "Completed At");
        JTable claimsTable = new JTable(claimsModel);
        UiUtil.styleTable(claimsTable, 28);
        claimsTable.getColumnModel().getColumn(6).setCellRenderer(UiUtil.TIMESTAMP_RENDERER);
        JPanel history = new JPanel(new BorderLayout(5, 8));
        history.add(UiUtil.sectionTitle("Claims history (completed handovers)"), BorderLayout.NORTH);
        history.add(new JScrollPane(claimsTable), BorderLayout.CENTER);
        panel.add(history, BorderLayout.CENTER);
        return panel;
    }

    /** "Label: value" with a muted label, as small HTML. */
    private static String kv(String key, Object value) {
        return "<html><span style='color:#8D7B6B'>" + key + ":</span>&nbsp; " + value + "</html>";
    }

    private static String[] prepend(String first, String[] rest) {
        String[] all = new String[rest.length + 1];
        all[0] = first;
        System.arraycopy(rest, 0, all, 1, rest.length);
        return all;
    }

    // ============================================================== loading
    /** One database connection is used for the whole refresh instead of one per query. */
    private void refreshAll() {
        try (Connection c = DBConfig.getConnection()) {
            DonationDAO.expireOld(c);
            profile = UserDAO.getProfile(c, userId);
            showProfile();
            fillBrowse(searchListings(c));
            fillPickups(DonationDAO.pendingPickups(c, userId));
            fillRequests(RequestDAO.listByRecipient(c, userId));
            fillClaims(DonationDAO.claimsHistory(c, userId));
        } catch (SQLException ex) {
            UiUtil.showDbError(this, ex);
        }
    }

    private void refreshBrowseOnly() {
        try (Connection c = DBConfig.getConnection()) {
            DonationDAO.expireOld(c);
            fillBrowse(searchListings(c));
        } catch (SQLException ex) {
            UiUtil.showDbError(this, ex);
        }
    }

    private List<Object[]> searchListings(Connection c) throws SQLException {
        String type = typeFilterBox.getSelectedIndex() == 0 ? null : (String) typeFilterBox.getSelectedItem();
        String foodName = foodNameFilterField.getText().trim();
        String donor = donorFilterField.getText().trim();
        Integer hours = timeFilterBox.getSelectedIndex() == 0 ? null : TIME_FILTER_HOURS[timeFilterBox.getSelectedIndex()];
        String city = (cityOnlyBox.isSelected() && profile != null && profile.city != null && !profile.city.isEmpty())
                ? profile.city : null;
        return DonationDAO.searchAvailable(c, type, foodName.isEmpty() ? null : foodName,
                donor.isEmpty() ? null : donor, hours, city);
    }

    private void showProfile() {
        if (profile == null) return;
        welcomeLabel.setText("Welcome, " + nameOrDefault(profile.institution));
        instLabel.setText(profile.institution);
        idLabel.setText(kv("Account ID", userId + "   \u2022   " + profile.username));
        phoneLabel.setText(kv("Contact Phone", profile.phone));
        cityLabel.setText(kv("City", profile.city));
        capacityLabel.setText(kv("Occupant Capacity", profile.capacity == null ? "Not set - please edit your profile" : profile.capacity));
        addressLabel.setText(kv("Address", profile.address));
    }

    private void fillBrowse(List<Object[]> rows) {
        browseModel.setRowCount(0);
        for (Object[] r : rows) {
            browseModel.addRow(new Object[]{r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8],
                    UiUtil.formatRemaining((Timestamp) r[8])});
        }
        browseStatusLabel.setText(rows.size() + " listing(s) found   \u2022   updated "
                + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
    }

    private void fillPickups(List<Object[]> rows) {
        pickupModel.setRowCount(0);
        for (Object[] r : rows) pickupModel.addRow(r);
        pickupStatusLabel.setText(rows.size() + " pickup(s) waiting   \u2022   updated "
                + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
    }

    private void fillRequests(List<Object[]> rows) {
        requestModel.setRowCount(0);
        for (Object[] r : rows) requestModel.addRow(r);
    }

    private void fillClaims(List<Object[]> rows) {
        claimsModel.setRowCount(0);
        for (Object[] r : rows) claimsModel.addRow(r);
    }

    /** Live time-to-expiry counter, refreshed every second without touching the database. */
    private void tickCountdown() {
        for (int r = 0; r < browseModel.getRowCount(); r++) {
            browseModel.setValueAt(UiUtil.formatRemaining((Timestamp) browseModel.getValueAt(r, 8)), r, 9);
        }
    }

    // ============================================================== actions
    private void claimSelected() {
        int row = browseTable.getSelectedRow();
        if (row < 0) {
            UiUtil.showWarn(this, "Please select a food listing first.");
            return;
        }
        int listingId = (Integer) browseModel.getValueAt(row, 0);
        String summary = browseModel.getValueAt(row, 6) + " " + String.valueOf(browseModel.getValueAt(row, 7)).toLowerCase()
                + " of " + browseModel.getValueAt(row, 4) + " (" + browseModel.getValueAt(row, 5) + ") from "
                + browseModel.getValueAt(row, 1);
        if (!UiUtil.confirm(this, "Accept " + summary + "?\nYou will get an OTP and must collect the food from the donor's place.")) return;

        ClaimService.Result result = ClaimService.claim(listingId);
        if (result.success) UiUtil.showInfo(this, result.message); else UiUtil.showWarn(this, result.message);
        refreshAll();
    }

    private void cancelSelectedPickup() {
        int row = pickupTable.getSelectedRow();
        if (row < 0) {
            UiUtil.showWarn(this, "Please select a pickup first.");
            return;
        }
        int listingId = (Integer) pickupModel.getValueAt(row, 0);
        if (!UiUtil.confirm(this, "Cancel your pickup for listing #" + listingId + "?\nYour OTP will stop working.")) return;

        ClaimService.Result result = ClaimService.releasePickup(listingId);
        if (result.success) UiUtil.showInfo(this, result.message); else UiUtil.showWarn(this, result.message);
        refreshAll();
    }

    private void submitRequirement() {
        String name = reqNameField.getText().trim();
        if (name.isEmpty()) {
            UiUtil.showError(this, "Please enter the name of the food you need (for example: Chapati).");
            return;
        }
        if (name.length() > 100) {
            UiUtil.showError(this, "The food name is too long. Please keep it within 100 characters.");
            return;
        }
        Integer servings = UiUtil.parsePositiveInt(reqServingsField.getText());
        if (servings == null || servings > 100000) {
            UiUtil.showError(this, "Servings needed must be a whole number between 1 and 100000.");
            return;
        }
        String type = (String) reqTypeBox.getSelectedItem();
        String urgency = (String) reqUrgencyBox.getSelectedItem();

        try (Connection c = DBConfig.getConnection()) {
            if (editingRequestId < 0) {
                RequestDAO.create(c, userId, name, type, servings, urgency);
                UiUtil.showInfo(this, "Your requirement has been published to donors.");
            } else {
                int changed = RequestDAO.update(c, editingRequestId, userId, name, type, servings, urgency);
                if (changed == 0) {
                    UiUtil.showWarn(this, "This request can no longer be edited because a donor has already accepted it.");
                } else {
                    UiUtil.showInfo(this, "Requirement updated.");
                }
            }
            resetRequirementForm();
            fillRequests(RequestDAO.listByRecipient(c, userId));
        } catch (SQLException ex) {
            UiUtil.showDbError(this, ex);
        }
    }

    private void startEditRequirement() {
        int row = requestTable.getSelectedRow();
        if (row < 0) {
            UiUtil.showWarn(this, "Please select a requirement to edit.");
            return;
        }
        if (!"OPEN".equals(requestModel.getValueAt(row, 5))) {
            UiUtil.showWarn(this, "Only open requirements can be edited. Accepted ones are waiting for the donor's handover.");
            return;
        }
        editingRequestId = (Integer) requestModel.getValueAt(row, 0);
        reqNameField.setText(String.valueOf(requestModel.getValueAt(row, 1)));
        reqTypeBox.setSelectedItem(requestModel.getValueAt(row, 2));
        reqServingsField.setText(String.valueOf(requestModel.getValueAt(row, 3)));
        reqUrgencyBox.setSelectedItem(requestModel.getValueAt(row, 4));
        reqFormTitle.setText("Editing requirement #" + editingRequestId);
        reqSubmitButton.setText("Save Changes");
        reqCancelEditButton.setVisible(true);
    }

    private void resetRequirementForm() {
        editingRequestId = -1;
        reqNameField.setText("");
        reqServingsField.setText("");
        reqTypeBox.setSelectedIndex(0);
        reqUrgencyBox.setSelectedItem("MEDIUM");
        reqFormTitle.setText("New requirement");
        reqSubmitButton.setText("Publish Requirement");
        reqCancelEditButton.setVisible(false);
    }

    private void deleteSelectedRequirement() {
        int row = requestTable.getSelectedRow();
        if (row < 0) {
            UiUtil.showWarn(this, "Please select a requirement to delete.");
            return;
        }
        if (!"OPEN".equals(requestModel.getValueAt(row, 5))) {
            UiUtil.showWarn(this, "Only open requirements can be deleted. Accepted and fulfilled ones are kept as history.");
            return;
        }
        int requestId = (Integer) requestModel.getValueAt(row, 0);
        if (!UiUtil.confirm(this, "Delete requirement #" + requestId + "?")) return;

        try (Connection c = DBConfig.getConnection()) {
            RequestDAO.delete(c, requestId, userId);
            if (editingRequestId == requestId) resetRequirementForm();
            fillRequests(RequestDAO.listByRecipient(c, userId));
        } catch (SQLException ex) {
            UiUtil.showDbError(this, ex);
        }
    }

    private void logout() {
        Session.end();           // revoke access
        dispose();
        new LoginForm();
    }

    @Override
    public void dispose() {
        if (countdownTimer != null) countdownTimer.stop();
        super.dispose();
    }

    private static String nameOrDefault(String name) {
        return (name == null || name.isEmpty()) ? "Recipient Account" : name.toUpperCase();
    }
}
