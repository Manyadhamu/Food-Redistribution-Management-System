package registration;

import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Business rules for the pickup flow (FR6 / FR8 / NFR4).
 *
 * Status life-cycle of a food_donations row:
 *     AVAILABLE --(recipient accepts / donor accepts a request)--> PENDING  (waiting for pickup, OTP issued)
 *     PENDING   --(donor enters the recipient's OTP)------------> CLAIMED  (handover complete, logged)
 *     PENDING   --(either side releases it)--------------------> AVAILABLE again (or CANCELLED for a request)
 *
 * The recipient always holds the OTP and tells it to the donor at handover; the donor always confirms it.
 * Every operation runs in ONE database transaction.
 */
public final class ClaimService {

    private static final SecureRandom RANDOM = new SecureRandom();

    /** How long a donor has to hand over food for an accepted shortage request. */
    private static final int REQUEST_HANDOVER_HOURS = 24;

    private ClaimService() { }

    public static final class Result {
        public final boolean success;
        public final String message;
        /** The pickup OTP, only set when a recipient has just accepted a listing or a donor accepted a request. */
        public final String otp;

        Result(boolean success, String message) {
            this(success, message, null);
        }

        Result(boolean success, String message, String otp) {
            this.success = success;
            this.message = message;
            this.otp = otp;
        }
    }

    private static String newOtp() {
        return String.format("%06d", RANDOM.nextInt(1_000_000));
    }

    // ------------------------------------------------ recipient accepts a listing
    /**
     * A recipient accepts an available listing. The listing is NOT claimed yet: it moves to PENDING and
     * a 6-digit pickup OTP is issued. It becomes CLAIMED only when the donor confirms that OTP.
     */
    public static Result claim(int listingId) {
        if (!Session.hasRole(Session.RECIPIENT)) {
            return new Result(false, "Only recipient accounts can accept food listings.");
        }
        int recipientId = Session.getUserId();

        try (Connection c = DBConfig.getConnection()) {
            c.setAutoCommit(false);
            try {
                int quantity;
                String unit, status, donorName;
                boolean live;
                String lockSql = "SELECT f.portions, f.quantity_unit, f.status, "
                        + "CASE WHEN f.expiry_timestamp > CURRENT_TIMESTAMP THEN 1 ELSE 0 END AS live, "
                        + "(SELECT u.institution_name FROM app_users u WHERE u.user_id = f.donor_id) AS donor_name "
                        + "FROM food_donations f WHERE f.listing_id = ? FOR UPDATE";
                try (PreparedStatement ps = c.prepareStatement(lockSql)) {
                    ps.setInt(1, listingId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) return fail(c, "This listing could not be found. Please refresh the list.");
                        quantity = rs.getInt("portions");
                        unit = rs.getString("quantity_unit");
                        status = rs.getString("status");
                        live = rs.getInt("live") == 1;
                        donorName = rs.getString("donor_name");
                    }
                }

                // Double-accept prevention (PENDING means someone else is already on their way)
                if (!"AVAILABLE".equals(status)) {
                    return fail(c, "Sorry, this listing is no longer available. Someone else may have accepted it.");
                }
                if (!live) {
                    return fail(c, "This listing has expired and can no longer be accepted.");
                }
                Integer capacity = UserDAO.getCapacity(c, recipientId);
                if (capacity == null) {
                    return fail(c, "Please set your occupant capacity in the Profile tab before accepting food.");
                }
                if (quantity > capacity) {
                    return fail(c, "This listing has " + quantity + " " + unit.toLowerCase()
                            + ", which is more than your capacity of " + capacity + ".");
                }

                String recipientName = UserDAO.getInstitutionName(c, recipientId);
                String otp = newOtp();

                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE food_donations SET status = 'PENDING', recipient_name = ?, reserved_by = ?, "
                                + "reserved_at = CURRENT_TIMESTAMP, pickup_otp = ? "
                                + "WHERE listing_id = ? AND status = 'AVAILABLE'")) {
                    ps.setString(1, recipientName != null ? recipientName : String.valueOf(recipientId));
                    ps.setInt(2, recipientId);
                    ps.setString(3, otp);
                    ps.setInt(4, listingId);
                    if (ps.executeUpdate() != 1) return fail(c, "Sorry, this listing was just accepted by someone else.");
                }

                c.commit();
                return new Result(true, "Accepted! Please go to " + (donorName != null ? donorName : "the donor")
                        + " to collect the food.\n\nYour pickup OTP:  " + otp
                        + "\n\nTell this OTP to the donor when you arrive. The donation stays PENDING until the donor "
                        + "confirms it. You can see the OTP again in the \"My Pickups\" tab.", otp);
            } catch (SQLException ex) {
                c.rollback();
                throw ex;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return new Result(false, UiUtil.friendlyMessage(ex));
        }
    }

    // ---------------------------------------------------------- fulfil request
    /**
     * A donor accepts a recipient's open shortage request. The request moves to ACCEPTED and a PENDING
     * donation row (linked to the request) is created with a pickup OTP for the recipient.
     * It completes when the donor confirms the OTP.
     */
    public static Result fulfillRequest(int requestId) {
        if (!Session.hasRole(Session.DONOR)) {
            return new Result(false, "Only donor accounts can accept requirement requests.");
        }
        int donorId = Session.getUserId();

        try (Connection c = DBConfig.getConnection()) {
            c.setAutoCommit(false);
            try {
                String recipientIdText, foodName, foodType, status;
                int servings;
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT recipient_id, NVL(food_name_needed, food_type_needed) AS food_name_needed, "
                                + "food_type_needed, servings_needed, status FROM recipient "
                                + "WHERE request_id = ? FOR UPDATE")) {
                    ps.setInt(1, requestId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) return fail(c, "This request could not be found. Please refresh the list.");
                        recipientIdText = rs.getString("recipient_id");
                        foodName = rs.getString("food_name_needed");
                        foodType = rs.getString("food_type_needed");
                        servings = rs.getInt("servings_needed");
                        status = rs.getString("status");
                    }
                }
                if (!"OPEN".equals(status)) {
                    return fail(c, "This request has already been accepted by another donor.");
                }

                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE recipient SET status = 'ACCEPTED' WHERE request_id = ? AND status = 'OPEN'")) {
                    ps.setInt(1, requestId);
                    if (ps.executeUpdate() != 1) return fail(c, "This request was just accepted by another donor.");
                }

                int recipientId = Integer.parseInt(recipientIdText);
                String recipientName = UserDAO.getInstitutionName(c, recipientId);
                String otp = newOtp();

                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO food_donations (donor_id, food_name, food_type, portions, quantity_unit, expiry_hours, "
                                + "status, recipient_name, expiry_timestamp, reserved_by, reserved_at, pickup_otp, request_id) "
                                + "VALUES (?, ?, ?, ?, 'SERVINGS', ?, 'PENDING', ?, "
                                + "CURRENT_TIMESTAMP + NUMTODSINTERVAL(?, 'HOUR'), ?, CURRENT_TIMESTAMP, ?, ?)")) {
                    ps.setInt(1, donorId);
                    ps.setString(2, foodName);      // the name the recipient asked for
                    ps.setString(3, foodType);
                    ps.setInt(4, servings);
                    ps.setInt(5, REQUEST_HANDOVER_HOURS);
                    ps.setString(6, recipientName != null ? recipientName : recipientIdText);
                    ps.setInt(7, REQUEST_HANDOVER_HOURS);
                    ps.setInt(8, recipientId);
                    ps.setString(9, otp);
                    ps.setInt(10, requestId);
                    ps.executeUpdate();
                }

                c.commit();
                return new Result(true, "Request accepted. The handover is now PENDING.\n\nThe recipient can see a pickup OTP "
                        + "in their \"My Pickups\" tab. When you hand over the food, ask for that OTP and enter it with "
                        + "\"Confirm Handover\" in My Active Listings. You have " + REQUEST_HANDOVER_HOURS + " hours.", otp);
            } catch (SQLException | NumberFormatException ex) {
                c.rollback();
                throw ex instanceof SQLException ? (SQLException) ex : new SQLException(ex);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return new Result(false, UiUtil.friendlyMessage(ex));
        }
    }

    // ------------------------------------------------------- donor confirms OTP
    /**
     * The donor types the OTP the recipient tells them. If it matches, the listing becomes CLAIMED,
     * the linked request (if any) becomes FULFILLED, and the log and donor counter are written.
     */
    public static Result confirmHandover(int listingId, String otpText) {
        if (!Session.hasRole(Session.DONOR)) {
            return new Result(false, "Only donor accounts can confirm a handover.");
        }
        int donorId = Session.getUserId();
        String entered = otpText == null ? "" : otpText.trim();
        if (!entered.matches("\\d{6}")) {
            return new Result(false, "The OTP is a 6-digit number. Please ask the recipient for it again.");
        }

        try (Connection c = DBConfig.getConnection()) {
            c.setAutoCommit(false);
            try {
                int ownerId, reservedBy;
                Integer requestId;
                String status, savedOtp;
                boolean live;
                String lockSql = "SELECT donor_id, status, pickup_otp, reserved_by, request_id, "
                        + "CASE WHEN expiry_timestamp > CURRENT_TIMESTAMP THEN 1 ELSE 0 END AS live "
                        + "FROM food_donations WHERE listing_id = ? FOR UPDATE";
                try (PreparedStatement ps = c.prepareStatement(lockSql)) {
                    ps.setInt(1, listingId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) return fail(c, "This listing could not be found. Please refresh the list.");
                        ownerId = rs.getInt("donor_id");
                        status = rs.getString("status");
                        savedOtp = rs.getString("pickup_otp");
                        reservedBy = rs.getInt("reserved_by");
                        int rid = rs.getInt("request_id");
                        requestId = rs.wasNull() ? null : rid;
                        live = rs.getInt("live") == 1;
                    }
                }
                if (ownerId != donorId) return fail(c, "You can only confirm handovers for your own listings.");
                if (!"PENDING".equals(status)) {
                    return fail(c, "This listing is not waiting for a pickup, so there is nothing to confirm.");
                }
                if (!live) return fail(c, "The pickup window for this listing has expired. Please refresh the list.");
                if (savedOtp == null || !savedOtp.equals(entered)) {
                    return fail(c, "That OTP does not match. Please check the number with the recipient and try again.");
                }

                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE food_donations SET status = 'CLAIMED', pickup_otp = NULL "
                                + "WHERE listing_id = ? AND status = 'PENDING'")) {
                    ps.setInt(1, listingId);
                    if (ps.executeUpdate() != 1) return fail(c, "This listing was just changed. Please refresh the list.");
                }
                if (requestId != null) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "UPDATE recipient SET status = 'FULFILLED' WHERE request_id = ? AND status = 'ACCEPTED'")) {
                        ps.setInt(1, requestId);
                        ps.executeUpdate();
                    }
                }

                insertLog(c, listingId, donorId, reservedBy);
                incrementDonorCount(c, donorId);

                c.commit();
                return new Result(true, "OTP verified. The donation is now CLAIMED and the handover has been recorded.");
            } catch (SQLException ex) {
                c.rollback();
                throw ex;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return new Result(false, UiUtil.friendlyMessage(ex));
        }
    }

    // ------------------------------------------------------------ release / cancel
    /**
     * Cancels a PENDING pickup. Allowed for the recipient who accepted it, or the donor who owns it.
     *  - a normal donation goes back to AVAILABLE (or TERMINATED if it has expired meanwhile)
     *  - a donation created from a shortage request is CANCELLED and the request goes back to OPEN
     */
    public static Result releasePickup(int listingId) {
        boolean asRecipient = Session.hasRole(Session.RECIPIENT);
        boolean asDonor = Session.hasRole(Session.DONOR);
        if (!asRecipient && !asDonor) return new Result(false, "Please log in again.");
        int me = Session.getUserId();

        try (Connection c = DBConfig.getConnection()) {
            c.setAutoCommit(false);
            try {
                int ownerId, reservedBy;
                Integer requestId;
                String status;
                boolean live;
                String lockSql = "SELECT donor_id, status, reserved_by, request_id, "
                        + "CASE WHEN expiry_timestamp > CURRENT_TIMESTAMP THEN 1 ELSE 0 END AS live "
                        + "FROM food_donations WHERE listing_id = ? FOR UPDATE";
                try (PreparedStatement ps = c.prepareStatement(lockSql)) {
                    ps.setInt(1, listingId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) return fail(c, "This listing could not be found. Please refresh the list.");
                        ownerId = rs.getInt("donor_id");
                        status = rs.getString("status");
                        reservedBy = rs.getInt("reserved_by");
                        int rid = rs.getInt("request_id");
                        requestId = rs.wasNull() ? null : rid;
                        live = rs.getInt("live") == 1;
                    }
                }
                if (!"PENDING".equals(status)) return fail(c, "This pickup is not waiting any more, so it cannot be cancelled.");
                if (asRecipient && reservedBy != me) return fail(c, "This pickup does not belong to you.");
                if (asDonor && ownerId != me) return fail(c, "This is not your listing.");

                if (requestId != null) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "UPDATE food_donations SET status = 'CANCELLED', pickup_otp = NULL WHERE listing_id = ?")) {
                        ps.setInt(1, listingId);
                        ps.executeUpdate();
                    }
                    try (PreparedStatement ps = c.prepareStatement(
                            "UPDATE recipient SET status = 'OPEN' WHERE request_id = ? AND status = 'ACCEPTED'")) {
                        ps.setInt(1, requestId);
                        ps.executeUpdate();
                    }
                    c.commit();
                    return new Result(true, "Pickup cancelled. The shortage request is open to donors again.");
                }

                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE food_donations SET status = ?, recipient_name = NULL, reserved_by = NULL, "
                                + "reserved_at = NULL, pickup_otp = NULL WHERE listing_id = ?")) {
                    ps.setString(1, live ? "AVAILABLE" : "TERMINATED");
                    ps.setInt(2, listingId);
                    ps.executeUpdate();
                }
                c.commit();
                return new Result(true, live ? "Pickup cancelled. The listing is available to other recipients again."
                        : "Pickup cancelled. The listing had already expired, so it was closed.");
            } catch (SQLException ex) {
                c.rollback();
                throw ex;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return new Result(false, UiUtil.friendlyMessage(ex));
        }
    }

    // ---------------------------------------------------------------- helpers
    /** FR8 - log id comes from a sequence; written only when the handover is CONFIRMED. */
    private static void insertLog(Connection c, int listingId, int donorId, int recipientId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO distribution_logs (log_id, listing_id, donor_id, recipient_id, claimed_at) "
                        + "VALUES (seq_log_id.NEXTVAL, ?, ?, ?, CURRENT_TIMESTAMP)")) {
            ps.setInt(1, listingId);
            ps.setInt(2, donorId);
            ps.setString(3, String.valueOf(recipientId));
            ps.executeUpdate();
        }
    }

    private static void incrementDonorCount(Connection c, int donorId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE donor SET total_completed_handlers = NVL(total_completed_handlers, 0) + 1 WHERE donor_id = ?")) {
            ps.setString(1, String.valueOf(donorId));
            ps.executeUpdate();
        }
    }

    private static Result fail(Connection c, String message) throws SQLException {
        c.rollback();   // releases the row lock
        return new Result(false, message);
    }
}
