package registration;

import javax.swing.*;
import java.awt.Component;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Pattern;

/** FR2 - lets a user update institution name, contact details, address, city and (recipients) occupant capacity. */
public final class ProfileDialog {

    private ProfileDialog() { }

    /** Shows the edit form. Returns true if the profile was saved. */
    public static boolean edit(Component parent, int userId, boolean isRecipient) {
        UiUtil.installTheme();
        UserDAO.Profile p;
        try (Connection c = DBConfig.getConnection()) {
            p = UserDAO.getProfile(c, userId);
        } catch (SQLException ex) {
            UiUtil.showDbError(parent, ex);
            return false;
        }
        if (p == null) {
            UiUtil.showError(parent, "Your account details could not be found.");
            return false;
        }

        JTextField instField = new JTextField(p.institution);
        JTextField phoneField = new JTextField(p.phone);
        JTextArea addressArea = new JTextArea(p.address);
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        JTextField cityField = new JTextField(p.city);
        JTextField capacityField = new JTextField(p.capacity == null ? "" : String.valueOf(p.capacity));

        JPanel form = isRecipient
                ? UiUtil.form(new String[]{"Institution Name", "Contact Phone (10 digits)", "Physical Address", "City", "Occupant Capacity"},
                new JComponent[]{instField, phoneField, UiUtil.textAreaScroll(addressArea, 3), cityField, capacityField})
                : UiUtil.form(new String[]{"Institution Name", "Contact Phone (10 digits)", "Physical Address", "City"},
                new JComponent[]{instField, phoneField, UiUtil.textAreaScroll(addressArea, 3), cityField});

        while (true) {
            int choice = JOptionPane.showConfirmDialog(parent, form, "Edit Profile",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (choice != JOptionPane.OK_OPTION) return false;

            String inst = instField.getText().trim();
            String phone = phoneField.getText().trim();
            String address = addressArea.getText().trim();
            String city = cityField.getText().trim();

            if (inst.isEmpty() || phone.isEmpty() || address.isEmpty() || city.isEmpty()) {
                UiUtil.showWarn(parent, "Please fill out all fields.");
                continue;
            }
            if (inst.length() > 150 || address.length() > 500 || city.length() > 50) {
                UiUtil.showError(parent, "One of the entries is too long. Please shorten it.");
                continue;
            }
            if (!Pattern.matches("^\\d{10}$", phone)) {
                UiUtil.showError(parent, "Contact Phone must be exactly 10 digits.");
                continue;
            }
            Integer capacity = null;
            if (isRecipient) {
                capacity = UiUtil.parsePositiveInt(capacityField.getText());
                if (capacity == null || capacity > 100000) {
                    UiUtil.showError(parent, "Occupant Capacity must be a whole number between 1 and 100000.");
                    continue;
                }
            }

            try (Connection c = DBConfig.getConnection()) {
                UserDAO.updateProfile(c, userId, inst, phone, address, city, capacity);
                return true;
            } catch (SQLException ex) {
                UiUtil.showDbError(parent, ex);
                return false;
            }
        }
    }
}
