package registration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Data access for the "recipient" table, which stores each institution's dietary requirement
 * requests (FR4). Only OPEN requests can be edited or deleted; fulfilled ones stay as history.
 */
public final class RequestDAO {

    private RequestDAO() { }

    public static void create(Connection c, int recipientId, String foodName, String foodType, int servings,
                              String urgency) throws SQLException {
        String sql = "INSERT INTO recipient (request_id, recipient_id, food_name_needed, food_type_needed, "
                + "servings_needed, urgency, status, created_at) "
                + "VALUES (seq_request_id.NEXTVAL, ?, ?, ?, ?, ?, 'OPEN', CURRENT_TIMESTAMP)";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, String.valueOf(recipientId));
            ps.setString(2, foodName);
            ps.setString(3, foodType);
            ps.setInt(4, servings);
            ps.setString(5, urgency);
            ps.executeUpdate();
        }
    }

    /** Returns rows changed (0 = request no longer open or not yours). */
    public static int update(Connection c, int requestId, int recipientId, String foodName, String foodType,
                             int servings, String urgency) throws SQLException {
        String sql = "UPDATE recipient SET food_name_needed = ?, food_type_needed = ?, servings_needed = ?, urgency = ? "
                + "WHERE request_id = ? AND recipient_id = ? AND status = 'OPEN'";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, foodName);
            ps.setString(2, foodType);
            ps.setInt(3, servings);
            ps.setString(4, urgency);
            ps.setInt(5, requestId);
            ps.setString(6, String.valueOf(recipientId));
            return ps.executeUpdate();
        }
    }

    public static int delete(Connection c, int requestId, int recipientId) throws SQLException {
        String sql = "DELETE FROM recipient WHERE request_id = ? AND recipient_id = ? AND status = 'OPEN'";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, requestId);
            ps.setString(2, String.valueOf(recipientId));
            return ps.executeUpdate();
        }
    }

    /** Row: request_id, food_name_needed, food_type_needed, servings_needed, urgency, status, created_at */
    public static List<Object[]> listByRecipient(Connection c, int recipientId) throws SQLException {
        String sql = "SELECT request_id, NVL(food_name_needed, food_type_needed) AS food_name_needed, "
                + "food_type_needed, servings_needed, urgency, status, created_at "
                + "FROM recipient WHERE recipient_id = ? ORDER BY request_id DESC";
        List<Object[]> rows = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, String.valueOf(recipientId));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{rs.getInt("request_id"), rs.getString("food_name_needed"),
                            rs.getString("food_type_needed"), rs.getInt("servings_needed"),
                            rs.getString("urgency"), rs.getString("status"), rs.getTimestamp("created_at")});
                }
            }
        }
        return rows;
    }

    /**
     * Open requests shown to donors, most urgent first. city = null shows every city.
     * Row: request_id, institution, city, food_name_needed, food_type_needed, servings_needed, urgency, created_at
     */
    public static List<Object[]> listOpenForDonor(Connection c, String city) throws SQLException {
        String sql = "SELECT r.request_id, u.institution_name, u.city, "
                + "NVL(r.food_name_needed, r.food_type_needed) AS food_name_needed, r.food_type_needed, "
                + "r.servings_needed, r.urgency, r.created_at FROM recipient r "
                + "JOIN app_users u ON TO_CHAR(u.user_id) = r.recipient_id "
                + "WHERE r.status = 'OPEN'" + (city != null ? " AND UPPER(u.city) = UPPER(?)" : "")
                + " ORDER BY CASE r.urgency WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 ELSE 4 END, "
                + "r.created_at ASC";
        List<Object[]> rows = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            if (city != null) ps.setString(1, city);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{rs.getInt("request_id"), rs.getString("institution_name"),
                            rs.getString("city"), rs.getString("food_name_needed"), rs.getString("food_type_needed"),
                            rs.getInt("servings_needed"), rs.getString("urgency"), rs.getTimestamp("created_at")});
                }
            }
        }
        return rows;
    }
}
