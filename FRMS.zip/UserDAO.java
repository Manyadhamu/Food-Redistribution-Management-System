package registration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

public final class UserDAO {

    private UserDAO() { }

    public static final class AuthResult {
        public static final int OK = 0, BAD_CREDENTIALS = 1, WRONG_ROLE = 2;
        public int status = BAD_CREDENTIALS;
        public int userId;
        public String role;
        public String institution;
    }

    public static AuthResult authenticate(Connection c, String username, String password, String selectedRole)
            throws SQLException {
        AuthResult result = new AuthResult();
        String sql = "SELECT user_id, password, role, institution_name FROM app_users WHERE username = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String stored = rs.getString("password");
                    boolean legacyPlainText = !PasswordUtil.isHashed(stored);
                    boolean ok = legacyPlainText ? stored.equals(password) : PasswordUtil.verify(password, stored);
                    if (!ok) continue;

                    result.userId = rs.getInt("user_id");
                    result.role = rs.getString("role");
                    result.institution = rs.getString("institution_name");
                    result.status = result.role.equals(selectedRole) ? AuthResult.OK : AuthResult.WRONG_ROLE;
                    if (legacyPlainText) upgradePassword(c, result.userId, password);
                    break;
                }
            }
        }
        return result;
    }

    private static void upgradePassword(Connection c, int userId, String password) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("UPDATE app_users SET password = ? WHERE user_id = ?")) {
            ps.setString(1, PasswordUtil.hash(password));
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }
    public static int register(Connection c, String role, String username, String passwordHash,
                               String institution, String certificate, String phone,
                               String address, String city, Integer capacity) throws SQLException {
        boolean previousAutoCommit = c.getAutoCommit();
        c.setAutoCommit(false);
        try {
            int id;
            try (PreparedStatement ps = c.prepareStatement("SELECT seq_user_id.NEXTVAL FROM dual");
                 ResultSet rs = ps.executeQuery()) {
                rs.next();
                id = rs.getInt(1);
            }

            String sql = "INSERT INTO app_users (user_id, role, username, password, institution_name, "
                    + "certificate_number, contact_phone, physical_address, city, occupant_capacity, registration_date) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, id);
                ps.setString(2, role);
                ps.setString(3, username);
                ps.setString(4, passwordHash);
                ps.setString(5, institution);
                ps.setString(6, certificate);
                ps.setString(7, phone);
                ps.setString(8, address);
                ps.setString(9, city);
                if (capacity == null) ps.setNull(10, Types.NUMERIC); else ps.setInt(10, capacity);
                ps.executeUpdate();
            }

            if (Session.DONOR.equals(role)) {
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO donor (donor_id, donor_type, total_completed_handlers) VALUES (?, 'Standard', 0)")) {
                    ps.setString(1, String.valueOf(id));
                    ps.executeUpdate();
                }
            }
            c.commit();
            return id;
        } catch (SQLException ex) {
            c.rollback();
            throw ex;
        } finally {
            c.setAutoCommit(previousAutoCommit);
        }
    }
    public static final class Profile {
        public int userId;
        public String role, username, institution, certificate, phone, address, city;
        public Integer capacity;            
        public String donorType;           
        public int completedHandovers;      
    }

    public static Profile getProfile(Connection c, int userId) throws SQLException {
        String sql = "SELECT u.role, u.username, u.institution_name, u.certificate_number, u.contact_phone, "
                + "u.physical_address, u.city, u.occupant_capacity, d.donor_type, d.total_completed_handlers "
                + "FROM app_users u LEFT JOIN donor d ON d.donor_id = TO_CHAR(u.user_id) WHERE u.user_id = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                Profile p = new Profile();
                p.userId = userId;
                p.role = rs.getString("role");
                p.username = rs.getString("username");
                p.institution = rs.getString("institution_name");
                p.certificate = rs.getString("certificate_number");
                p.phone = rs.getString("contact_phone");
                p.address = rs.getString("physical_address");
                p.city = rs.getString("city");
                int cap = rs.getInt("occupant_capacity");
                p.capacity = rs.wasNull() ? null : cap;
                p.donorType = rs.getString("donor_type");
                p.completedHandovers = rs.getInt("total_completed_handlers");
                return p;
            }
        }
    }

    public static void updateProfile(Connection c, int userId, String institution, String phone,
                                     String address, String city, Integer capacity) throws SQLException {
        String sql = "UPDATE app_users SET institution_name = ?, contact_phone = ?, physical_address = ?, city = ?"
                + (capacity != null ? ", occupant_capacity = ?" : "") + " WHERE user_id = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setString(i++, institution);
            ps.setString(i++, phone);
            ps.setString(i++, address);
            ps.setString(i++, city);
            if (capacity != null) ps.setInt(i++, capacity);
            ps.setInt(i, userId);
            ps.executeUpdate();
        }
    }

    public static Integer getCapacity(Connection c, int userId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT occupant_capacity FROM app_users WHERE user_id = ?")) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                int cap = rs.getInt(1);
                return rs.wasNull() ? null : cap;
            }
        }
    }

    public static String getInstitutionName(Connection c, int userId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT institution_name FROM app_users WHERE user_id = ?")) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        }
    }
}
