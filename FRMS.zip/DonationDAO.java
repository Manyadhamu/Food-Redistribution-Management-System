package registration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/** Data access for food_donations (FR3, FR5, FR7). All statements are parameterised. */
public final class DonationDAO {

    private DonationDAO() { }

    public static final class DonorMetrics {
        public int activeListings;
        public int pendingRequests;
        public long totalServings;
        public long totalKg;
        public int completedHandovers;
    }

    /**
     * Housekeeping: listings past their expiry time are closed so nobody can claim them.
     * A PENDING pickup that was never completed in time is closed too, and if it came from a
     * shortage request, that request goes back to OPEN so another donor can take it.
     */
    public static int expireOld(Connection c) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE recipient SET status = 'OPEN' WHERE status = 'ACCEPTED' AND request_id IN ("
                        + "SELECT request_id FROM food_donations WHERE status = 'PENDING' "
                        + "AND request_id IS NOT NULL AND expiry_timestamp <= CURRENT_TIMESTAMP)")) {
            ps.executeUpdate();
        }
        String sql = "UPDATE food_donations SET status = 'TERMINATED', pickup_otp = NULL "
                + "WHERE status IN ('AVAILABLE', 'PENDING') AND expiry_timestamp <= CURRENT_TIMESTAMP";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            return ps.executeUpdate();
        }
    }

    // ------------------------------------------------------------------ donor
    public static void create(Connection c, int donorId, String foodName, String foodType, int quantity, String unit, int hours)
            throws SQLException {
        String sql = "INSERT INTO food_donations (donor_id, food_name, food_type, portions, quantity_unit, expiry_hours, "
                + "status, recipient_name, expiry_timestamp) "
                + "VALUES (?, ?, ?, ?, ?, ?, 'AVAILABLE', NULL, CURRENT_TIMESTAMP + NUMTODSINTERVAL(?, 'HOUR'))";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, donorId);
            ps.setString(2, foodName);
            ps.setString(3, foodType);
            ps.setInt(4, quantity);
            ps.setString(5, unit);
            ps.setInt(6, hours);
            ps.setInt(7, hours);
            ps.executeUpdate();
        }
    }

    /** FR3 - edit only while the listing is still unclaimed and not expired. Returns rows changed (0 = not editable). */
    public static int update(Connection c, int listingId, int donorId, String foodName, String foodType, int quantity,
                             String unit, int hours) throws SQLException {
        String sql = "UPDATE food_donations SET food_name = ?, food_type = ?, portions = ?, quantity_unit = ?, expiry_hours = ?, "
                + "expiry_timestamp = CURRENT_TIMESTAMP + NUMTODSINTERVAL(?, 'HOUR') "
                + "WHERE listing_id = ? AND donor_id = ? AND status = 'AVAILABLE' AND expiry_timestamp > CURRENT_TIMESTAMP";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, foodName);
            ps.setString(2, foodType);
            ps.setInt(3, quantity);
            ps.setString(4, unit);
            ps.setInt(5, hours);
            ps.setInt(6, hours);
            ps.setInt(7, listingId);
            ps.setInt(8, donorId);
            return ps.executeUpdate();
        }
    }

    /** FR3 - withdraw an unclaimed listing. The row is kept (status CANCELLED) so history stays complete. */
    public static int cancel(Connection c, int listingId, int donorId) throws SQLException {
        String sql = "UPDATE food_donations SET status = 'CANCELLED' "
                + "WHERE listing_id = ? AND donor_id = ? AND status = 'AVAILABLE'";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, listingId);
            ps.setInt(2, donorId);
            return ps.executeUpdate();
        }
    }

    /**
     * Listings that are still open: AVAILABLE ones and PENDING ones (accepted, waiting for the OTP handover).
     * Row: listing_id, food_name, food_type, portions, unit, expiry, status, recipient_name
     */
    public static List<Object[]> listActive(Connection c, int donorId) throws SQLException {
        String sql = "SELECT listing_id, NVL(food_name, food_type) AS food_name, food_type, portions, quantity_unit, "
                + "expiry_timestamp, status, recipient_name "
                + "FROM food_donations WHERE donor_id = ? AND status IN ('AVAILABLE', 'PENDING') "
                + "AND expiry_timestamp > CURRENT_TIMESTAMP "
                + "ORDER BY CASE status WHEN 'PENDING' THEN 1 ELSE 2 END, expiry_timestamp ASC";
        List<Object[]> rows = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, donorId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{rs.getInt("listing_id"), rs.getString("food_name"), rs.getString("food_type"),
                            rs.getInt("portions"), rs.getString("quantity_unit"),
                            rs.getTimestamp("expiry_timestamp"), rs.getString("status"), rs.getString("recipient_name")});
                }
            }
        }
        return rows;
    }

    /** Row: listing_id, food_name, food_type, portions, unit, status, recipient_name, expiry  (latest 500, FR3 ledger) */
    public static List<Object[]> listHistory(Connection c, int donorId) throws SQLException {
        String sql = "SELECT * FROM (SELECT listing_id, NVL(food_name, food_type) AS food_name, food_type, portions, quantity_unit, status, "
                + "recipient_name, expiry_timestamp FROM food_donations WHERE donor_id = ? "
                + "ORDER BY listing_id DESC) WHERE ROWNUM <= 500";
        List<Object[]> rows = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, donorId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{rs.getInt("listing_id"), rs.getString("food_name"), rs.getString("food_type"),
                            rs.getInt("portions"), rs.getString("quantity_unit"), rs.getString("status"),
                            rs.getString("recipient_name"), rs.getTimestamp("expiry_timestamp")});
                }
            }
        }
        return rows;
    }

    /** FR7 - all counters from one aggregate query instead of loading every row into Java. */
    public static DonorMetrics metrics(Connection c, int donorId) throws SQLException {
        DonorMetrics m = new DonorMetrics();
        String sql = "SELECT "
                + "COUNT(CASE WHEN status = 'AVAILABLE' AND expiry_timestamp > CURRENT_TIMESTAMP THEN 1 END) AS active_cnt, "
                + "NVL(SUM(CASE WHEN status = 'CLAIMED' AND quantity_unit = 'SERVINGS' THEN portions END), 0) AS servings_total, "
                + "NVL(SUM(CASE WHEN status = 'CLAIMED' AND quantity_unit = 'KG' THEN portions END), 0) AS kg_total "
                + "FROM food_donations WHERE donor_id = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, donorId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    m.activeListings = rs.getInt("active_cnt");
                    m.totalServings = rs.getLong("servings_total");
                    m.totalKg = rs.getLong("kg_total");
                }
            }
        }
        try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM recipient WHERE status = 'OPEN'");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) m.pendingRequests = rs.getInt(1);
        }
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT NVL(total_completed_handlers, 0) FROM donor WHERE donor_id = ?")) {
            ps.setString(1, String.valueOf(donorId));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) m.completedHandovers = rs.getInt(1);
            }
        }
        return m;
    }

    // -------------------------------------------------------------- recipient
    /**
     * FR5 - discovery with filters. Any filter may be null (= not applied).
     * Row: listing_id, donor_name, address, city, food_name, food_type, portions, unit, expiry
     * Nearest expiry first.
     */
    public static List<Object[]> searchAvailable(Connection c, String foodType, String foodName, String donorName,
                                                 Integer withinHours, String city) throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT f.listing_id, u.institution_name, u.physical_address, u.city, "
                + "NVL(f.food_name, f.food_type) AS food_name, f.food_type, "
                + "f.portions, f.quantity_unit, f.expiry_timestamp "
                + "FROM food_donations f JOIN app_users u ON u.user_id = f.donor_id "
                + "WHERE f.status = 'AVAILABLE' AND f.expiry_timestamp > CURRENT_TIMESTAMP");
        List<Object> params = new ArrayList<>();
        if (foodType != null) {
            sql.append(" AND f.food_type = ?");
            params.add(foodType);
        }
        if (foodName != null) {
            sql.append(" AND UPPER(NVL(f.food_name, f.food_type)) LIKE UPPER(?)");
            params.add("%" + foodName + "%");
        }
        if (donorName != null) {
            sql.append(" AND UPPER(u.institution_name) LIKE UPPER(?)");
            params.add("%" + donorName + "%");
        }
        if (withinHours != null) {
            sql.append(" AND f.expiry_timestamp <= CURRENT_TIMESTAMP + NUMTODSINTERVAL(?, 'HOUR')");
            params.add(withinHours);
        }
        if (city != null) {
            sql.append(" AND UPPER(u.city) = UPPER(?)");
            params.add(city);
        }
        sql.append(" ORDER BY f.expiry_timestamp ASC");

        List<Object[]> rows = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) ps.setObject(i + 1, params.get(i));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{rs.getInt("listing_id"), rs.getString("institution_name"),
                            rs.getString("physical_address"), rs.getString("city"), rs.getString("food_name"),
                            rs.getString("food_type"), rs.getInt("portions"), rs.getString("quantity_unit"),
                            rs.getTimestamp("expiry_timestamp")});
                }
            }
        }
        return rows;
    }

    /** Row: listing_id, donor_name, food_name, food_type, portions, unit, claimed_at */
    public static List<Object[]> claimsHistory(Connection c, int recipientId) throws SQLException {
        String sql = "SELECT f.listing_id, u.institution_name, NVL(f.food_name, f.food_type) AS food_name, f.food_type, "
                + "f.portions, f.quantity_unit, dl.claimed_at "
                + "FROM distribution_logs dl "
                + "JOIN food_donations f ON f.listing_id = dl.listing_id "
                + "JOIN app_users u ON u.user_id = f.donor_id "
                + "WHERE dl.recipient_id = ? ORDER BY dl.claimed_at DESC";
        List<Object[]> rows = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, String.valueOf(recipientId));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{rs.getInt("listing_id"), rs.getString("institution_name"),
                            rs.getString("food_name"), rs.getString("food_type"), rs.getInt("portions"),
                            rs.getString("quantity_unit"), rs.getTimestamp("claimed_at")});
                }
            }
        }
        return rows;
    }

    /**
     * Pickups a recipient has accepted but not yet collected, with the OTP to tell the donor.
     * Row: listing_id, donor_name, address, city, phone, food_name, portions, unit, otp, expiry
     */
    public static List<Object[]> pendingPickups(Connection c, int recipientId) throws SQLException {
        String sql = "SELECT f.listing_id, u.institution_name, u.physical_address, u.city, u.contact_phone, "
                + "NVL(f.food_name, f.food_type) AS food_name, f.portions, f.quantity_unit, f.pickup_otp, f.expiry_timestamp "
                + "FROM food_donations f JOIN app_users u ON u.user_id = f.donor_id "
                + "WHERE f.reserved_by = ? AND f.status = 'PENDING' ORDER BY f.reserved_at DESC";
        List<Object[]> rows = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, recipientId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new Object[]{rs.getInt("listing_id"), rs.getString("institution_name"),
                            rs.getString("physical_address"), rs.getString("city"), rs.getString("contact_phone"),
                            rs.getString("food_name"), rs.getInt("portions"), rs.getString("quantity_unit"),
                            rs.getString("pickup_otp"), rs.getTimestamp("expiry_timestamp")});
                }
            }
        }
        return rows;
    }
}
