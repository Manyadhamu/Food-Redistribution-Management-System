package registration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Single place that knows how to connect to the database.
 * The connection details live in "db.properties" (NFR6 - configuration isolation),
 * so moving to another machine only needs that file edited - no code change.
 *
 * Lookup order for the file:
 *   1. the path given by -Ddb.config=...   2. ./db.properties   3. db.properties on the classpath
 */
public final class DBConfig {

    private static final String DEFAULT_FILE = "db.properties";
    private static Properties props;

    private DBConfig() { }

    private static synchronized Properties load() throws SQLException {
        if (props != null) return props;

        Properties p = new Properties();
        String path = System.getProperty("db.config", DEFAULT_FILE);
        File file = new File(path);
        try {
            if (file.isFile()) {
                try (InputStream in = new FileInputStream(file)) {
                    p.load(in);
                }
            } else {
                try (InputStream in = DBConfig.class.getClassLoader().getResourceAsStream(DEFAULT_FILE)) {
                    if (in == null) {
                        throw new SQLException("The settings file '" + path + "' was not found. "
                                + "Please place db.properties next to the application.", "CONFIG");
                    }
                    p.load(in);
                }
            }
        } catch (IOException e) {
            throw new SQLException("The settings file could not be read.", "CONFIG", e);
        }
        props = p;
        return props;
    }

    /** Opens a new connection. Always use inside try-with-resources. */
    public static Connection getConnection() throws SQLException {
        Properties p = load();
        String url = p.getProperty("db.url");
        String user = p.getProperty("db.user");
        String pass = p.getProperty("db.password");
        if (url == null || user == null || pass == null) {
            throw new SQLException("The settings file must contain db.url, db.user and db.password.", "CONFIG");
        }
        return DriverManager.getConnection(url.trim(), user.trim(), pass);
    }
}
