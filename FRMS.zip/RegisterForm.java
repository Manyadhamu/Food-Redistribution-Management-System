package registration;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Pattern;

/** Presentation layer for registration (FR2). Database work is delegated to UserDAO. */
public class RegisterForm extends JFrame {

    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final int MIN_PASSWORD_LENGTH = 6;

    private JTextField instField, certField, userField, phoneField, cityField, capacityField;
    private JPasswordField passField, confirmPassField;
    private JTextArea addressArea;
    private JLabel capacityLabel;
    private JPanel capacityBox;
    private JRadioButton donorRadio, recipientRadio;

    public RegisterForm() {
        UiUtil.installTheme();
        setTitle("User Registration - Food Redistribution Management");
        setSize(600, 780);
        setMinimumSize(new Dimension(560, 560));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(buildHeader(), BorderLayout.NORTH);

        JScrollPane scroll = new JScrollPane(buildForm());
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        add(buildFooter(), BorderLayout.SOUTH);
        updateRoleFields();
        setVisible(true);
    }

    // ------------------------------------------------------------------ pieces
    private JPanel buildHeader() {
        JLabel title = new JLabel("Create your account");
        return UiUtil.appHeader(title, "Join the network - share surplus food or find it", "REGISTRATION", null);
    }

    private JPanel buildForm() {
        JPanel page = new JPanel(new GridBagLayout());
        page.setBackground(Color.WHITE);
        page.setBorder(new EmptyBorder(22, 36, 10, 36));

        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.gridwidth = 2;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.anchor = GridBagConstraints.WEST;
        int y = 0;

        // role picker
        donorRadio = new JRadioButton("Donor", true);
        recipientRadio = new JRadioButton("Recipient");
        for (JRadioButton r : new JRadioButton[]{donorRadio, recipientRadio}) {
            r.setOpaque(false);
            r.setFont(UiUtil.font(Font.PLAIN, 14f));
        }
        ButtonGroup group = new ButtonGroup();
        group.add(donorRadio);
        group.add(recipientRadio);
        donorRadio.addActionListener(e -> updateRoleFields());
        recipientRadio.addActionListener(e -> updateRoleFields());
        JPanel roles = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        roles.setOpaque(false);
        donorRadio.setBorder(new EmptyBorder(0, 0, 0, 26));
        roles.add(donorRadio);
        roles.add(recipientRadio);

        g.gridy = y++;
        g.insets = new Insets(0, 0, 4, 0);
        page.add(UiUtil.fieldLabel("I am registering as"), g);
        g.gridy = y++;
        g.insets = new Insets(0, 0, 16, 0);
        page.add(roles, g);

        // account
        y = section(page, g, y, "Organisation");
        instField = new JTextField();
        certField = new JTextField();
        y = pair(page, g, y, "Institution Name", instField, "Certificate Number", certField);

        y = section(page, g, y, "Sign-in details");
        userField = new JTextField();
        userField.setToolTipText("Your email address is your username");
        y = single(page, g, y, "Email (Username)", userField);
        passField = new JPasswordField();
        confirmPassField = new JPasswordField();
        y = pair(page, g, y, "New Password", passField, "Confirm Password", confirmPassField);

        y = section(page, g, y, "Contact & location");
        phoneField = new JTextField();
        cityField = new JTextField();
        y = pair(page, g, y, "Contact Phone (10 digits)", phoneField, "City", cityField);
        addressArea = new JTextArea();
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        y = single(page, g, y, "Physical Address", UiUtil.textAreaScroll(addressArea, 3));

        capacityField = new JTextField();
        capacityLabel = UiUtil.fieldLabel("Occupant Capacity");
        capacityBox = new JPanel(new BorderLayout(0, 4));
        capacityBox.setOpaque(false);
        capacityBox.add(capacityLabel, BorderLayout.NORTH);
        capacityBox.add(capacityField, BorderLayout.CENTER);
        g.gridy = y++;
        g.insets = new Insets(0, 0, 8, 0);
        page.add(capacityBox, g);

        // push everything to the top
        GridBagConstraints filler = new GridBagConstraints();
        filler.gridy = y;
        filler.weighty = 1;
        page.add(Box.createVerticalGlue(), filler);
        return page;
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel(new GridLayout(1, 3, 12, 0));
        footer.setBackground(Color.WHITE);
        footer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, UiUtil.BORDER), new EmptyBorder(14, 36, 16, 36)));
        JButton registerButton = UiUtil.primary("Register");
        JButton clearButton = UiUtil.secondary("Clear");
        JButton backButton = UiUtil.secondary("Back");
        footer.add(registerButton);
        footer.add(clearButton);
        footer.add(backButton);

        registerButton.addActionListener(e -> handleRegistration());
        clearButton.addActionListener(e -> clearFields());
        backButton.addActionListener(e -> {
            new Welcome();
            dispose();
        });
        getRootPane().setDefaultButton(registerButton);
        return footer;
    }

    private int section(JPanel p, GridBagConstraints g, int y, String text) {
        JLabel l = UiUtil.sectionTitle(text);
        g.gridy = y;
        g.insets = new Insets(4, 0, 8, 0);
        p.add(l, g);
        return y + 1;
    }

    private int single(JPanel p, GridBagConstraints g, int y, String label, JComponent field) {
        g.gridy = y++;
        g.insets = new Insets(0, 0, 4, 0);
        p.add(UiUtil.fieldLabel(label), g);
        g.gridy = y++;
        g.insets = new Insets(0, 0, 14, 0);
        p.add(field, g);
        return y;
    }

    private int pair(JPanel p, GridBagConstraints g, int y, String l1, JComponent f1, String l2, JComponent f2) {
        JPanel row = new JPanel(new GridLayout(1, 2, 14, 0));
        row.setOpaque(false);
        row.add(labelled(l1, f1));
        row.add(labelled(l2, f2));
        g.gridy = y++;
        g.insets = new Insets(0, 0, 14, 0);
        p.add(row, g);
        return y;
    }

    private JPanel labelled(String label, JComponent field) {
        JPanel box = new JPanel(new BorderLayout(0, 4));
        box.setOpaque(false);
        box.add(UiUtil.fieldLabel(label), BorderLayout.NORTH);
        box.add(field, BorderLayout.CENTER);
        return box;
    }

    /** Occupant capacity only applies to recipients. */
    private void updateRoleFields() {
        capacityBox.setVisible(recipientRadio.isSelected());
        capacityBox.getParent().revalidate();
        capacityBox.getParent().repaint();
    }

    private void handleRegistration() {
        boolean recipient = recipientRadio.isSelected();
        String role = recipient ? Session.RECIPIENT : Session.DONOR;
        String username = userField.getText().trim();
        String password = new String(passField.getPassword());          // passwords are never trimmed
        String confirm = new String(confirmPassField.getPassword());
        String institution = instField.getText().trim();
        String certificate = certField.getText().trim();
        String phone = phoneField.getText().trim();
        String address = addressArea.getText().trim();
        String city = cityField.getText().trim();

        if (username.isEmpty() || password.isEmpty() || confirm.isEmpty() || institution.isEmpty()
                || certificate.isEmpty() || phone.isEmpty() || address.isEmpty() || city.isEmpty()) {
            UiUtil.showWarn(this, "Please fill out all fields.");
            return;
        }
        if (institution.length() > 150 || address.length() > 500 || city.length() > 50 || username.length() > 100) {
            UiUtil.showError(this, "One of the entries is too long. Please shorten it.");
            return;
        }
        if (certificate.length() > 15) {
            UiUtil.showError(this, "Certificate Number must not exceed 15 characters.");
            return;
        }
        if (!Pattern.matches("^\\d{10}$", phone)) {
            UiUtil.showError(this, "Contact Phone must be exactly 10 digits.");
            return;
        }
        if (!EMAIL.matcher(username).matches()) {
            UiUtil.showError(this, "Please enter a valid email address, for example name@example.com.");
            return;
        }
        if (password.length() < MIN_PASSWORD_LENGTH) {
            UiUtil.showError(this, "Password must be at least " + MIN_PASSWORD_LENGTH + " characters long.");
            return;
        }
        if (!password.equals(confirm)) {
            UiUtil.showError(this, "The two passwords do not match.");
            return;
        }
        Integer capacity = null;
        if (recipient) {
            capacity = UiUtil.parsePositiveInt(capacityField.getText());
            if (capacity == null || capacity > 100000) {
                UiUtil.showError(this, "Occupant Capacity must be a whole number between 1 and 100000.");
                return;
            }
        }

        try (Connection c = DBConfig.getConnection()) {
            UserDAO.register(c, role, username, PasswordUtil.hash(password), institution, certificate,
                    phone, address, city, capacity);
            UiUtil.showInfo(this, "Registration successful! You can now log in.");
            new LoginForm();
            dispose();
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1) {
                UiUtil.showError(this, "This email is already registered. Please log in or use a different email.");
            } else {
                UiUtil.showDbError(this, ex);
            }
        }
    }

    private void clearFields() {
        instField.setText("");
        certField.setText("");
        userField.setText("");
        passField.setText("");
        confirmPassField.setText("");
        phoneField.setText("");
        addressArea.setText("");
        cityField.setText("");
        capacityField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(RegisterForm::new);
    }
}
