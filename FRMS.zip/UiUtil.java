package registration;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.BorderUIResource;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.FontUIResource;
import javax.swing.plaf.IconUIResource;
import javax.swing.plaf.InsetsUIResource;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.Enumeration;

public final class UiUtil {

    public static final String[] FOOD_TYPES = {"Veg", "Non-Veg", "Dry", "Cooked"};
    public static final String[] UNITS = {"SERVINGS", "KG"};
    public static final String[] URGENCY_LEVELS = {"LOW", "MEDIUM", "HIGH", "CRITICAL"};

    public static final Color ORANGE       = new Color(0xF57C00);   
    public static final Color ORANGE_LIGHT = new Color(0xFF9800);   
    public static final Color ORANGE_DARK  = new Color(0xE65100);   
    public static final Color ORANGE_TINT  = new Color(0xFFF3E0);  
    public static final Color ORANGE_SEL   = new Color(0xFFE0B2);  
    public static final Color ZEBRA        = new Color(0xFFF9F2);  
    public static final Color BORDER       = new Color(0xF2D9BD);  
    public static final Color TEXT         = new Color(0x3E2F23);  
    public static final Color MUTED        = new Color(0x8D7B6B);  
    public static final Color WHITE        = Color.WHITE;
    public static final Color RED          = new Color(0xD32F2F);  
    public static final Color GREY         = new Color(0x6D5F54);  
    public static final Color SUCCESS      = new Color(0x2E7D32);  

    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm");
    private static final String FONT_FAMILY = pickFontFamily();
    private static boolean themeInstalled;

    private UiUtil() { }

    public static Font font(int style, float size) {
        return new Font(FONT_FAMILY, style, 1).deriveFont(style, size);
    }

    private static String pickFontFamily() {
        String[] wanted = {"Segoe UI", "Inter", "SF Pro Text", "Helvetica Neue", "Roboto", "Noto Sans", "DejaVu Sans"};
        java.util.Set<String> have = new java.util.HashSet<>(java.util.Arrays.asList(
                GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
        for (String f : wanted) if (have.contains(f)) return f;
        return Font.SANS_SERIF;
    }

    public static synchronized void installTheme() {
        if (themeInstalled) return;
        themeInstalled = true;
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) { }

        
        FontUIResource base = new FontUIResource(font(Font.PLAIN, 13f));
        for (Enumeration<Object> keys = UIManager.getDefaults().keys(); keys.hasMoreElements(); ) {
            Object key = keys.nextElement();
            if (key.toString().endsWith(".font")) UIManager.put(key, base);
        }
        UIManager.put("TabbedPane.font", new FontUIResource(font(Font.BOLD, 14f)));
        UIManager.put("TitledBorder.font", new FontUIResource(font(Font.BOLD, 13f)));
        UIManager.put("Button.font", new FontUIResource(font(Font.BOLD, 13f)));

        
        ColorUIResource white = new ColorUIResource(WHITE), text = new ColorUIResource(TEXT);
        for (String k : new String[]{"Panel.background", "OptionPane.background", "TabbedPane.background",
                "ScrollPane.background", "Viewport.background", "TextField.background", "TextArea.background",
                "PasswordField.background", "ComboBox.background", "List.background", "Table.background",
                "CheckBox.background", "RadioButton.background", "Label.background", "SplitPane.background",
                "TabbedPane.contentAreaColor", "TabbedPane.tabAreaBackground", "TabbedPane.selected"}) {
            UIManager.put(k, white);
        }
        for (String k : new String[]{"Label.foreground", "TextField.foreground", "TextArea.foreground",
                "PasswordField.foreground", "ComboBox.foreground", "List.foreground", "Table.foreground",
                "CheckBox.foreground", "RadioButton.foreground", "OptionPane.messageForeground",
                "TabbedPane.foreground", "TextField.caretForeground", "TextArea.caretForeground",
                "PasswordField.caretForeground"}) {
            UIManager.put(k, text);
        }
        ColorUIResource sel = new ColorUIResource(ORANGE_SEL);
        for (String k : new String[]{"TextField.selectionBackground", "TextArea.selectionBackground",
                "PasswordField.selectionBackground", "List.selectionBackground", "ComboBox.selectionBackground",
                "Table.selectionBackground"}) {
            UIManager.put(k, sel);
        }
        for (String k : new String[]{"TextField.selectionForeground", "TextArea.selectionForeground",
                "PasswordField.selectionForeground", "List.selectionForeground", "ComboBox.selectionForeground",
                "Table.selectionForeground"}) {
            UIManager.put(k, text);
        }
        UIManager.put("ComboBox.disabledForeground", new ColorUIResource(MUTED));
        UIManager.put("CheckBox.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("RadioButton.focus", new ColorUIResource(new Color(0, 0, 0, 0)));
        UIManager.put("ToolTip.background", new ColorUIResource(ORANGE_TINT));
        UIManager.put("ToolTip.border", new BorderUIResource(new RoundedBorder(BORDER, 6, new Insets(4, 8, 4, 8))));

        // borders
        UIManager.put("TextField.border", new BorderUIResource(new FieldBorder()));
        UIManager.put("PasswordField.border", new BorderUIResource(new FieldBorder()));
        UIManager.put("TextArea.border", new BorderUIResource(new EmptyBorder(6, 8, 6, 8)));
        UIManager.put("ScrollPane.border", new BorderUIResource(new RoundedBorder(BORDER, 10, new Insets(2, 2, 2, 2))));
        UIManager.put("Table.scrollPaneBorder", new BorderUIResource(new RoundedBorder(BORDER, 10, new Insets(2, 2, 2, 2))));
        UIManager.put("TitledBorder.border", new BorderUIResource(new RoundedBorder(BORDER, 12, new Insets(10, 12, 12, 12))));
        UIManager.put("TitledBorder.titleColor", new ColorUIResource(ORANGE_DARK));
        UIManager.put("Button.border", new BorderUIResource(new EmptyBorder(8, 18, 8, 18)));
        UIManager.put("Button.margin", new InsetsUIResource(0, 0, 0, 0));
        UIManager.put("OptionPane.border", new BorderUIResource(new EmptyBorder(16, 18, 14, 18)));
        UIManager.put("OptionPane.buttonAreaBorder", new BorderUIResource(new EmptyBorder(10, 0, 0, 0)));
        UIManager.put("OptionPane.buttonPadding", 10);
        UIManager.put("SplitPane.dividerSize", 6);
        UIManager.put("SplitPane.border", new BorderUIResource(new EmptyBorder(0, 0, 0, 0)));

        // component UIs
        UIManager.put("ButtonUI", ThemedButtonUI.class.getName());
        UIManager.put("ComboBoxUI", ThemedComboUI.class.getName());
        UIManager.put("TabbedPaneUI", ThemedTabsUI.class.getName());
        UIManager.put("ScrollBarUI", ThemedScrollBarUI.class.getName());
        UIManager.put("CheckBox.icon", new IconUIResource(new ToggleIcon(false)));
        UIManager.put("RadioButton.icon", new IconUIResource(new ToggleIcon(true)));

        UIManager.put("OptionPane.questionIcon", new IconUIResource(new MessageIcon("?", ORANGE)));
        UIManager.put("OptionPane.informationIcon", new IconUIResource(new MessageIcon("i", ORANGE)));
        UIManager.put("OptionPane.warningIcon", new IconUIResource(new MessageIcon("!", new Color(0xF9A825))));
        UIManager.put("OptionPane.errorIcon", new IconUIResource(new MessageIcon("\u00D7", RED)));

        KeyboardFocusManager.getCurrentKeyboardFocusManager().addPropertyChangeListener("permanentFocusOwner", e -> {
            for (Object o : new Object[]{e.getOldValue(), e.getNewValue()}) {
                if (o instanceof javax.swing.text.JTextComponent || o instanceof JComboBox) ((JComponent) o).repaint();
            }
        });
    }

    public static void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Please check", JOptionPane.ERROR_MESSAGE);
    }

    public static void showWarn(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Attention", JOptionPane.WARNING_MESSAGE);
    }

    public static void showInfo(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Done", JOptionPane.INFORMATION_MESSAGE);
    }

    public static boolean confirm(Component parent, String message) {
        return JOptionPane.showConfirmDialog(parent, message, "Please confirm",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    public static void showDbError(Component parent, Exception ex) {
        ex.printStackTrace();
        String text = (ex instanceof SQLException)
                ? friendlyMessage((SQLException) ex)
                : "Something went wrong. Please try again.";
        showError(parent, text);
    }

    public static String friendlyMessage(SQLException ex) {
        if ("CONFIG".equals(ex.getSQLState())) return ex.getMessage();
        switch (ex.getErrorCode()) {
            case 1:     return "This record already exists. Please use different details.";
            case 1017:  return "The application could not sign in to the database. Please check the database settings.";
            case 12541:
            case 12514:
            case 12505:
            case 17002:
            case 17410: return "The database is not reachable. Please make sure it is running and try again.";
            case 2290:  return "One of the values entered is not allowed. Please check your entries.";
            case 1400:  return "A required value is missing. Please fill in all fields.";
            case 12899: return "One of the entries is too long. Please shorten it.";
            case 2291:
            case 2292:  return "This record is linked to other records and cannot be changed.";
            case 20001: return "This record is protected and cannot be changed or deleted.";
            case 942:
            case 904:   return "The database has not been updated for this version. Please run the database update script.";
            default:    return "Something went wrong while saving or loading data. Please try again.";
        }
    }


    public static Integer parsePositiveInt(String text) {
        if (text == null) return null;
        try {
            int v = Integer.parseInt(text.trim());
            return v > 0 ? v : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** Live time-to-expiry text, e.g. "03:12:09" or "2d 4h 10m". */
    public static String formatRemaining(Timestamp expiry) {
        if (expiry == null) return "-";
        long secs = (expiry.getTime() - System.currentTimeMillis()) / 1000;
        if (secs <= 0) return "EXPIRED";
        long d = secs / 86400, h = (secs % 86400) / 3600, m = (secs % 3600) / 60, s = secs % 60;
        if (d > 0) return d + "d " + h + "h " + m + "m";
        return String.format("%02d:%02d:%02d", h, m, s);
    }

    public static final DefaultTableCellRenderer TIMESTAMP_RENDERER = new ThemedCellRenderer() {
        @Override
        protected void setValue(Object value) {
            setText(value instanceof Timestamp
                    ? ((Timestamp) value).toLocalDateTime().format(DATE_TIME)
                    : (value == null ? "" : value.toString()));
        }
    };

    public static DefaultTableModel readOnlyModel(String... columns) {
        return new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
    }

    public static void styleTable(JTable table, int rowHeight) {
        table.setRowHeight(Math.max(rowHeight, 32));
        table.setFont(font(Font.PLAIN, 13f));
        table.setForeground(TEXT);
        table.setBackground(WHITE);
        table.setShowGrid(false);
        table.setShowHorizontalLines(true);
        table.setGridColor(new Color(0xF7E7D3));
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setSelectionBackground(ORANGE_SEL);
        table.setSelectionForeground(TEXT);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setFillsViewportHeight(true);
        table.setDefaultRenderer(Object.class, new ThemedCellRenderer());
        table.setDefaultRenderer(Integer.class, new ThemedCellRenderer());

        JTableHeader header = table.getTableHeader();
        header.setReorderingAllowed(false);
        header.setBackground(ORANGE);
        header.setForeground(WHITE);
        header.setFont(font(Font.BOLD, 13f));
        header.setPreferredSize(new Dimension(100, 36));
        header.setDefaultRenderer(new HeaderRenderer());

        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
            TableColumn col = table.getColumnModel().getColumn(i);
            String name = String.valueOf(col.getHeaderValue());
            if (name.equals("Urgency") || name.equals("Status")) col.setCellRenderer(new BadgeRenderer());
            else if (name.equals("Time Left")) col.setCellRenderer(new CountdownRenderer());
        }
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.getModel().addTableModelListener(e -> {
            if (e.getType() == javax.swing.event.TableModelEvent.UPDATE) return;
            if (table.getClientProperty("ui.fitPending") != null) return;
            table.putClientProperty("ui.fitPending", Boolean.TRUE);
            SwingUtilities.invokeLater(() -> {
                table.putClientProperty("ui.fitPending", null);
                fitColumns(table);
            });
        });
        SwingUtilities.invokeLater(() -> fitColumns(table));
    }

    public static void fitColumns(JTable table) {
        for (int c = 0; c < table.getColumnCount(); c++) {
            TableColumn col = table.getColumnModel().getColumn(c);
            Component hc = table.getTableHeader().getDefaultRenderer()
                    .getTableCellRendererComponent(table, col.getHeaderValue(), false, false, -1, c);
            int w = hc.getPreferredSize().width + 8;
            for (int r = 0; r < table.getRowCount(); r++) {
                Component cc = table.prepareRenderer(table.getCellRenderer(r, c), r, c);
                w = Math.max(w, cc.getPreferredSize().width + 8);
            }
            col.setPreferredWidth(Math.min(Math.max(w, 60), 380));
        }
    }

    public static class ThemedCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                                                       boolean focus, int row, int col) {
            super.getTableCellRendererComponent(t, value, selected, false, row, col);
            setBorder(new EmptyBorder(0, 12, 0, 12));
            setForeground(TEXT);
            setBackground(selected ? ORANGE_SEL : (row % 2 == 0 ? WHITE : ZEBRA));
            setFont(font(Font.PLAIN, 13f));
            return this;
        }
    }

    private static final class HeaderRenderer implements TableCellRenderer {
        private final JLabel label = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(ORANGE);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(ORANGE_DARK);
                g.fillRect(0, getHeight() - 2, getWidth(), 2);
                super.paintComponent(g);
            }
        };

        HeaderRenderer() {
            label.setOpaque(false);
            label.setForeground(WHITE);
            label.setFont(font(Font.BOLD, 13f));
            label.setBorder(new EmptyBorder(0, 12, 0, 12));
        }

        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
            label.setText(v == null ? "" : v.toString());
            return label;
        }
        
    }

    private static final class BadgeRenderer extends ThemedCellRenderer {
        private Color pillBg = ORANGE_TINT, pillFg = ORANGE_DARK;
        private Color rowBg = WHITE;

        @Override
        public Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                                                       boolean focus, int row, int col) {
            super.getTableCellRendererComponent(t, value, selected, focus, row, col);
            String v = value == null ? "" : value.toString().toUpperCase();
            setText(v);
            setBorder(new EmptyBorder(0, 22, 0, 12));
            setFont(font(Font.BOLD, 11f));
            rowBg = getBackground();
            switch (v) {
                case "CRITICAL": pillBg = new Color(0xD32F2F); pillFg = WHITE; break;
                case "HIGH":     pillBg = new Color(0xF57C00); pillFg = WHITE; break;
                case "MEDIUM":   pillBg = new Color(0xFFE0B2); pillFg = new Color(0xB45F06); break;
                case "LOW":      pillBg = new Color(0xF3EBE2); pillFg = new Color(0x7A6A5C); break;
                case "OPEN":
                case "AVAILABLE": pillBg = new Color(0xFFE0B2); pillFg = new Color(0xB45F06); break;
                case "CLAIMED":
                case "FULFILLED": pillBg = new Color(0xDCEFDC); pillFg = SUCCESS; break;
                case "EXPIRED":
                case "TERMINATED":
                case "CANCELLED": pillBg = new Color(0xECE7E2); pillFg = new Color(0x7A6A5C); break;
                default:          pillBg = ORANGE_TINT; pillFg = ORANGE_DARK;
            }
            setForeground(pillFg);
            return this;
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(rowBg);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            FontMetrics fm = g2.getFontMetrics(getFont());
            int w = fm.stringWidth(getText()) + 20, h = 22;
            g2.setColor(pillBg);
            g2.fillRoundRect(12, (getHeight() - h) / 2, w, h, h, h);
            g2.dispose();
            setOpaque(false);
            super.paintComponent(g);
        }
    }

    private static final class CountdownRenderer extends ThemedCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                                                       boolean focus, int row, int col) {
            super.getTableCellRendererComponent(t, value, selected, focus, row, col);
            boolean expired = "EXPIRED".equals(String.valueOf(value));
            setForeground(expired ? RED : ORANGE_DARK);
            setFont(font(Font.BOLD, 13f));
            return this;
        }
    }

    private static final String VARIANT = "ui.variant";
    private static final String CUSTOM = "ui.color";

    public static JButton button(String text, Color background) {
        JButton b = new JButton(text);
        if (background == null || background.equals(ORANGE)) {
            b.putClientProperty(VARIANT, "primary");
        } else {
            b.putClientProperty(VARIANT, "custom");
            b.putClientProperty(CUSTOM, background);
        }
        return b;
    }

    public static JButton primary(String text)   { return button(text, null); }
    public static JButton danger(String text)    { return button(text, RED); }
    public static JButton neutral(String text)   { return button(text, GREY); }

    public static JButton secondary(String text) {
        JButton b = new JButton(text);
        b.putClientProperty(VARIANT, "secondary");
        return b;
    }

    /** Translucent white button, meant for the orange header bar. */
    public static JButton onHeader(String text) {
        JButton b = new JButton(text);
        b.putClientProperty(VARIANT, "header");
        return b;
    }

    /** Rounded buttons for every JButton in the app (including those inside dialogs). */
    public static class ThemedButtonUI extends BasicButtonUI {
        public static ComponentUI createUI(JComponent c) { return new ThemedButtonUI(); }

        @Override
        public void installUI(JComponent c) {
            super.installUI(c);
            AbstractButton b = (AbstractButton) c;
            b.setOpaque(false);
            b.setRolloverEnabled(true);
            b.setFocusPainted(false);
            b.setContentAreaFilled(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }

        private String variant(AbstractButton b) {
            Object v = b.getClientProperty(VARIANT);
            return v == null ? "secondary" : v.toString();
        }

        private Color fill(AbstractButton b) {
            ButtonModel m = b.getModel();
            String v = variant(b);
            Color base;
            switch (v) {
                case "primary": base = ORANGE; break;
                case "custom":  base = (Color) b.getClientProperty(CUSTOM); break;
                case "header":  return new Color(255, 255, 255, m.isPressed() ? 90 : m.isRollover() ? 70 : 45);
                default:        return m.isPressed() ? ORANGE_SEL : m.isRollover() ? ORANGE_TINT : WHITE;
            }
            if (!b.isEnabled()) return new Color(0xE9DFD5);
            if (m.isPressed()) return base.darker();
            if (m.isRollover()) return "primary".equals(v) ? ORANGE_LIGHT : brighten(base);
            return base;
        }

        private Color fg(AbstractButton b) {
            if (!b.isEnabled()) return new Color(0xA89888);
            String v = variant(b);
            return v.equals("secondary") ? ORANGE_DARK : WHITE;
        }

        private static Color brighten(Color c) {
            return new Color(Math.min(255, (int) (c.getRed() * 1.12 + 10)),
                    Math.min(255, (int) (c.getGreen() * 1.12 + 10)),
                    Math.min(255, (int) (c.getBlue() * 1.12 + 10)));
        }

        @Override
        public void paint(Graphics g, JComponent c) {
            AbstractButton b = (AbstractButton) c;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = c.getWidth(), h = c.getHeight(), arc = 12;
            if (variant(b).equals("primary") || variant(b).equals("custom")) {      // soft drop shadow
                g2.setColor(new Color(0, 0, 0, 22));
                g2.fill(new RoundRectangle2D.Float(0, 2, w, h - 1, arc, arc));
            }
            g2.setColor(fill(b));
            g2.fill(new RoundRectangle2D.Float(0, 0, w, h - 2, arc, arc));
            if (variant(b).equals("secondary")) {
                g2.setColor(b.isEnabled() ? ORANGE : new Color(0xD9CBBE));
                g2.setStroke(new BasicStroke(1.4f));
                g2.draw(new RoundRectangle2D.Float(0.7f, 0.7f, w - 1.4f, h - 3.4f, arc, arc));
            } else if (variant(b).equals("header")) {
                g2.setColor(new Color(255, 255, 255, 150));
                g2.setStroke(new BasicStroke(1f));
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, w - 1f, h - 3f, arc, arc));
            }
            g2.dispose();
            super.paint(g, c);
        }

        @Override
        protected void paintText(Graphics g, JComponent c, Rectangle textRect, String text) {
            AbstractButton b = (AbstractButton) c;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setFont(b.getFont());
            g2.setColor(fg(b));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(text, textRect.x, textRect.y + fm.getAscent() - 1);
            g2.dispose();
        }

        @Override
        protected void paintFocus(Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) { }
    }

    public static final class FieldBorder extends AbstractBorder {
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            boolean focus = c.hasFocus();
            g2.setColor(focus ? ORANGE : new Color(0xE3CFB8));
            g2.setStroke(new BasicStroke(focus ? 2f : 1.2f));
            g2.draw(new RoundRectangle2D.Float(x + 1, y + 1, w - 2.5f, h - 2.5f, 10, 10));
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) { return new Insets(7, 11, 7, 11); }

        @Override
        public Insets getBorderInsets(Component c, Insets i) {
            i.set(7, 11, 7, 11);
            return i;
        }
    }

    public static final class RoundedBorder extends AbstractBorder {
        private final Color colour;
        private final int arc;
        private final Insets insets;

        public RoundedBorder(Color colour, int arc, Insets insets) {
            this.colour = colour;
            this.arc = arc;
            this.insets = insets;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(colour);
            g2.setStroke(new BasicStroke(1.2f));
            g2.draw(new RoundRectangle2D.Float(x + 0.6f, y + 0.6f, w - 1.4f, h - 1.4f, arc, arc));
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) { return (Insets) insets.clone(); }

        @Override
        public Insets getBorderInsets(Component c, Insets i) {
            i.set(insets.top, insets.left, insets.bottom, insets.right);
            return i;
        }
    }

    public static class ThemedComboUI extends BasicComboBoxUI {
        public static ComponentUI createUI(JComponent c) { return new ThemedComboUI(); }

        @Override
        protected void installDefaults() {
            super.installDefaults();
            comboBox.setOpaque(false);
            comboBox.setBorder(new EmptyBorder(0, 0, 0, 0));
        }

        @Override
        protected JButton createArrowButton() {
            JButton b = new JButton() {
                @Override
                public void paint(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(ORANGE);
                    g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    int cx = getWidth() / 2, cy = getHeight() / 2;
                    g2.drawLine(cx - 4, cy - 2, cx, cy + 2);
                    g2.drawLine(cx, cy + 2, cx + 4, cy - 2);
                    g2.dispose();
                }
            };
            b.setBorder(new EmptyBorder(0, 0, 0, 0));
            b.setContentAreaFilled(false);
            b.setFocusable(false);
            b.setPreferredSize(new Dimension(26, 20));
            return b;
        }

        @Override
        public void paint(Graphics g, JComponent c) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = c.getWidth(), h = c.getHeight();
            g2.setColor(WHITE);
            g2.fill(new RoundRectangle2D.Float(0, 0, w, h, 10, 10));
            super.paint(g, c);
            boolean focus = comboBox.hasFocus() || comboBox.isPopupVisible();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(focus ? ORANGE : new Color(0xE3CFB8));
            g2.setStroke(new BasicStroke(focus ? 2f : 1.2f));
            g2.draw(new RoundRectangle2D.Float(1, 1, w - 2.5f, h - 2.5f, 10, 10));
            g2.dispose();
        }

        @Override
        public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) { }

        @Override
        protected Rectangle rectangleForCurrentValue() {
            Rectangle r = super.rectangleForCurrentValue();
            r.x += 9;
            r.width -= 9;
            r.y += 2;
            r.height -= 4;
            return r;
        }

        @Override
        public Dimension getPreferredSize(JComponent c) {
            Dimension d = super.getPreferredSize(c);
            return new Dimension(d.width + 26, Math.max(d.height + 6, 34));
        }
    }

    public static class ThemedTabsUI extends BasicTabbedPaneUI {
        public static ComponentUI createUI(JComponent c) { return new ThemedTabsUI(); }

        @Override
        protected void installDefaults() {
            super.installDefaults();
            tabInsets = new Insets(10, 22, 10, 22);
            selectedTabPadInsets = new Insets(0, 0, 0, 0);
            tabAreaInsets = new Insets(4, 10, 0, 10);
            contentBorderInsets = new Insets(1, 0, 0, 0);
            tabPane.setOpaque(true);
        }

        @Override
        protected void paintTabBackground(Graphics g, int tp, int idx, int x, int y, int w, int h, boolean sel) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(sel ? WHITE : (getRolloverTab() == idx ? ORANGE_TINT : WHITE));
            g2.fillRect(x, y, w, h);
            g2.dispose();
        }

        @Override
        protected void paintTabBorder(Graphics g, int tp, int idx, int x, int y, int w, int h, boolean sel) {
            if (!sel) return;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(ORANGE);
            g2.fill(new RoundRectangle2D.Float(x + 6, y + h - 3, w - 12, 3, 3, 3));
            g2.dispose();
        }

        @Override
        protected void paintText(Graphics g, int tp, Font font, FontMetrics fm, int idx, String title,
                                 Rectangle textRect, boolean sel) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setFont(font);
            g2.setColor(sel ? ORANGE_DARK : MUTED);
            g2.drawString(title, textRect.x, textRect.y + fm.getAscent());
            g2.dispose();
        }

        @Override
        protected void paintContentBorder(Graphics g, int tp, int sel) {
            Insets ins = tabPane.getInsets();
            Rectangle r = tabPane.getBounds();
            int tabAreaH = calculateTabAreaHeight(tp, runCount, maxTabHeight);
            g.setColor(BORDER);
            g.fillRect(ins.left, ins.top + tabAreaH - 1, r.width - ins.left - ins.right, 1);
        }

        @Override
        protected void paintFocusIndicator(Graphics g, int tp, Rectangle[] rects, int idx, Rectangle iconRect,
                                           Rectangle textRect, boolean sel) { }

        @Override
        protected int calculateTabHeight(int tp, int idx, int fontHeight) { return fontHeight + 22; }

        @Override protected int getTabLabelShiftX(int tp, int idx, boolean sel) { return 0; }
        @Override protected int getTabLabelShiftY(int tp, int idx, boolean sel) { return 0; }
    }

    public static class ThemedScrollBarUI extends BasicScrollBarUI {
        public static ComponentUI createUI(JComponent c) { return new ThemedScrollBarUI(); }

        @Override
        protected void configureScrollBarColors() {
            thumbColor = new Color(0xF3B063);
            trackColor = WHITE;
        }

        @Override
        public Dimension getPreferredSize(JComponent c) { return new Dimension(11, 11); }

        private JButton zero() {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            return b;
        }

        @Override protected JButton createDecreaseButton(int o) { return zero(); }
        @Override protected JButton createIncreaseButton(int o) { return zero(); }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
            g.setColor(WHITE);
            g.fillRect(r.x, r.y, r.width, r.height);
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            if (r.isEmpty() || !scrollbar.isEnabled()) return;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(isThumbRollover() || isDragging ? ORANGE : thumbColor);
            g2.fill(new RoundRectangle2D.Float(r.x + 2, r.y + 2, r.width - 4, r.height - 4, 8, 8));
            g2.dispose();
        }
    }

    /** Round icon with a single glyph, used by the message dialogs. */
    private static final class MessageIcon implements Icon {
        private final String glyph;
        private final Color colour;

        MessageIcon(String glyph, Color colour) {
            this.glyph = glyph;
            this.colour = colour;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(colour);
            g2.fill(new Ellipse2D.Float(x, y, 36, 36));
            g2.setColor(WHITE);
            g2.setFont(font(Font.BOLD, 22f));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(glyph, x + (36 - fm.stringWidth(glyph)) / 2, y + (36 - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }

        @Override public int getIconWidth() { return 36; }
        @Override public int getIconHeight() { return 36; }
    }

    // ============================================================ radio / check
    private static final class ToggleIcon implements Icon {
        private final boolean round;

        ToggleIcon(boolean round) { this.round = round; }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            AbstractButton b = (AbstractButton) c;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            boolean on = b.isSelected();
            int s = 18;
            Shape shape = round ? new Ellipse2D.Float(x + 1, y + 1, s - 2, s - 2)
                    : new RoundRectangle2D.Float(x + 1, y + 1, s - 2, s - 2, 6, 6);
            g2.setColor(on ? ORANGE : WHITE);
            g2.fill(shape);
            g2.setColor(on ? ORANGE : (b.getModel().isRollover() ? ORANGE : new Color(0xD9BFA0)));
            g2.setStroke(new BasicStroke(1.6f));
            g2.draw(shape);
            if (on) {
                g2.setColor(WHITE);
                if (round) {
                    g2.fill(new Ellipse2D.Float(x + 6, y + 6, 6, 6));
                } else {
                    g2.setStroke(new BasicStroke(2.2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    Path2D p = new Path2D.Float();
                    p.moveTo(x + 5, y + 9.5);
                    p.lineTo(x + 8, y + 12.5);
                    p.lineTo(x + 13, y + 6);
                    g2.draw(p);
                }
            }
            g2.dispose();
        }

        @Override public int getIconWidth() { return 20; }
        @Override public int getIconHeight() { return 20; }
    }

    public static class Card extends JPanel {
        private final Color accent;

        public Card(LayoutManager layout, Color accent) {
            super(layout);
            this.accent = accent;
            setOpaque(false);
        }

        public Card(LayoutManager layout) { this(layout, null); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth() - 2, h = getHeight() - 3;
            g2.setColor(new Color(150, 90, 20, 18));
            g2.fill(new RoundRectangle2D.Float(1, 3, w, h, 16, 16));
            g2.setColor(WHITE);
            g2.fill(new RoundRectangle2D.Float(0, 0, w, h, 16, 16));
            g2.setColor(BORDER);
            g2.setStroke(new BasicStroke(1.2f));
            g2.draw(new RoundRectangle2D.Float(0.6f, 0.6f, w - 1.2f, h - 1.2f, 16, 16));
            if (accent != null) {
                g2.setClip(new RoundRectangle2D.Float(0, 0, w, h, 16, 16));
                g2.setColor(accent);
                g2.fillRect(0, 0, 6, h);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static JPanel appHeader(JLabel title, String caption, String roleTag, JButton logout) {
        JPanel bar = new JPanel(new BorderLayout(14, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, ORANGE_LIGHT, getWidth(), getHeight(), ORANGE_DARK));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 28));          // decorative circles
                g2.fill(new Ellipse2D.Float(getWidth() - 220, -80, 200, 200));
                g2.fill(new Ellipse2D.Float(getWidth() - 120, 20, 120, 120));
                g2.dispose();
            }
        };
        bar.setOpaque(false);
        bar.setBorder(new EmptyBorder(16, 24, 16, 24));

        JLabel logo = new JLabel(new LogoIcon(46, true));
        title.setFont(font(Font.BOLD, 21f));
        title.setForeground(WHITE);
        JLabel sub = new JLabel(caption);
        sub.setFont(font(Font.PLAIN, 12f));
        sub.setForeground(new Color(255, 255, 255, 215));
        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);
        text.add(title);
        text.add(Box.createVerticalStrut(2));
        text.add(sub);

        JPanel left = new JPanel(new BorderLayout(14, 0));
        left.setOpaque(false);
        left.add(logo, BorderLayout.WEST);
        left.add(text, BorderLayout.CENTER);
        bar.add(left, BorderLayout.CENTER);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 6));
        right.setOpaque(false);
        JLabel tag = new JLabel(roleTag) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        tag.setFont(font(Font.BOLD, 11f));
        tag.setForeground(ORANGE_DARK);
        tag.setBorder(new EmptyBorder(5, 14, 5, 14));
        right.add(tag);
        if (logout != null) right.add(logout);
        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    public static final class LogoIcon implements Icon {
        private final int size;
        private final boolean onOrange;

        public LogoIcon(int size, boolean onOrange) {
            this.size = size;
            this.onOrange = onOrange;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
            g2.translate(x, y);
            double s = size / 46.0;
            g2.scale(s, s);
            Color disc = onOrange ? WHITE : ORANGE;
            Color ink = onOrange ? ORANGE : WHITE;
            g2.setColor(disc);
            g2.fill(new Ellipse2D.Float(0, 0, 46, 46));
            g2.setColor(ink);
            Path2D bowl = new Path2D.Float();                       // bowl
            bowl.moveTo(10, 25);
            bowl.lineTo(36, 25);
            bowl.curveTo(36, 35, 30, 38, 23, 38);
            bowl.curveTo(16, 38, 10, 35, 10, 25);
            bowl.closePath();
            g2.fill(bowl);
            g2.fill(new RoundRectangle2D.Float(15, 38.5f, 16, 3, 3, 3));
            g2.setStroke(new BasicStroke(2.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            for (int i = 0; i < 3; i++) {                           // steam
                Path2D st = new Path2D.Float();
                float sx = 16 + i * 7;
                st.moveTo(sx, 21);
                st.curveTo(sx - 3, 17, sx + 3, 14, sx, 9);
                g2.draw(st);
            }
            g2.dispose();
        }

        @Override public int getIconWidth() { return size; }
        @Override public int getIconHeight() { return size; }
    }

    public static JLabel metricCard(JPanel row, String title, Color accent) {
        Card card = new Card(new BorderLayout(0, 4), accent);
        card.setBorder(new EmptyBorder(14, 22, 14, 14));
        JLabel t = new JLabel(title);
        t.setFont(font(Font.BOLD, 11f));
        t.setForeground(MUTED);
        JLabel v = new JLabel("0");
        v.setFont(font(Font.BOLD, 18f));
        v.setForeground(TEXT);
        card.add(t, BorderLayout.NORTH);
        card.add(v, BorderLayout.CENTER);
        row.add(card);
        return v;
    }

    public static JLabel fieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(font(Font.BOLD, 12f));
        l.setForeground(GREY);
        return l;
    }

    /** Page heading inside a tab. */
    public static JLabel sectionTitle(String text) {
        JLabel l = new JLabel(text);
        l.setFont(font(Font.BOLD, 15f));
        l.setForeground(ORANGE_DARK);
        return l;
    }

    public static JLabel statusLine() {
        JLabel l = new JLabel(" ");
        l.setFont(font(Font.PLAIN, 12f));
        l.setForeground(MUTED);
        return l;
    }


    public static JPanel form(String[] labels, JComponent[] fields) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.anchor = GridBagConstraints.WEST;
        int y = 0;
        for (int i = 0; i < labels.length; i++) {
            g.gridy = y++;
            g.insets = new Insets(i == 0 ? 0 : 10, 0, 3, 0);
            p.add(fieldLabel(labels[i]), g);
            g.gridy = y++;
            g.insets = new Insets(0, 0, 0, 0);
            p.add(fields[i], g);
        }
        p.setPreferredSize(new Dimension(360, p.getPreferredSize().height));
        return p;
    }


    public static JScrollPane textAreaScroll(JTextArea area, int rows) {
        area.setRows(rows);
        area.setFont(font(Font.PLAIN, 13f));
        JScrollPane sp = new JScrollPane(area);
        sp.setBorder(new RoundedBorder(new Color(0xE3CFB8), 10, new Insets(2, 2, 2, 2)));
        return sp;
    }
}
