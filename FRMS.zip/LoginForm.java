package registration;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.sql.Connection;
import java.sql.SQLException;

/** Presentation layer for login (FR1). Verification is done by UserDAO + PasswordUtil. */
public class LoginForm extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JRadioButton donorRadio, recipientRadio;
    private JLabel statusLabel;

    public LoginForm() {
        UiUtil.installTheme();
        setTitle("Login - Food Redistribution Management");
        setSize(840, 520);
        setMinimumSize(new Dimension(760, 480));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));

        add(buildBrandPanel());
        add(buildFormPanel());

        getRootPane().setDefaultButton(defaultButton);   // Enter key logs in
        setVisible(true);
    }

    private JButton defaultButton;

    // ------------------------------------------------------------ left: brand
    private JPanel buildBrandPanel() {
        JPanel brand = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, UiUtil.ORANGE_LIGHT, getWidth(), getHeight(), UiUtil.ORANGE_DARK));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 30));
                g2.fill(new Ellipse2D.Float(-90, getHeight() - 220, 320, 320));
                g2.fill(new Ellipse2D.Float(getWidth() - 160, -90, 260, 260));
                g2.setColor(new Color(255, 255, 255, 22));
                g2.fill(new Ellipse2D.Float(getWidth() - 110, getHeight() - 150, 170, 170));
                g2.dispose();
            }
        };
        brand.setLayout(new GridBagLayout());
        brand.setBorder(new EmptyBorder(30, 40, 30, 40));

        JPanel stack = new JPanel();
        stack.setOpaque(false);
        stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel(new UiUtil.LogoIcon(64, true));
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel name = new JLabel("<html>Food Redistribution<br>Management</html>");
        name.setFont(UiUtil.font(Font.BOLD, 28f));
        name.setForeground(Color.WHITE);
        name.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel tag = new JLabel("<html>Connecting surplus food with the<br>people who need it - fast.</html>");
        tag.setFont(UiUtil.font(Font.PLAIN, 14f));
        tag.setForeground(new Color(255, 255, 255, 225));
        tag.setAlignmentX(Component.LEFT_ALIGNMENT);

        stack.add(logo);
        stack.add(Box.createVerticalStrut(22));
        stack.add(name);
        stack.add(Box.createVerticalStrut(12));
        stack.add(tag);
        stack.add(Box.createVerticalStrut(26));
        for (String line : new String[]{"Donors list surplus food in seconds",
                "Recipients claim before it expires", "Every handover is tracked"}) {
            JLabel l = new JLabel("✓   " + line);
            l.setFont(UiUtil.font(Font.PLAIN, 13f));
            l.setForeground(Color.WHITE);
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            l.setBorder(new EmptyBorder(3, 0, 3, 0));
            stack.add(l);
        }
        brand.add(stack);
        return brand;
    }

    // ------------------------------------------------------------ right: form
    private JPanel buildFormPanel() {
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(Color.WHITE);
        right.setBorder(new EmptyBorder(30, 48, 30, 48));

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.anchor = GridBagConstraints.WEST;
        int y = 0;

        JLabel title = new JLabel("Welcome back");
        title.setFont(UiUtil.font(Font.BOLD, 26f));
        title.setForeground(UiUtil.ORANGE_DARK);
        g.gridy = y++;
        form.add(title, g);

        JLabel sub = new JLabel("Sign in to continue");
        sub.setFont(UiUtil.font(Font.PLAIN, 13f));
        sub.setForeground(UiUtil.MUTED);
        g.gridy = y++;
        g.insets = new Insets(2, 0, 20, 0);
        form.add(sub, g);

        usernameField = new JTextField();
        passwordField = new JPasswordField();           // characters are masked
        usernameField.setToolTipText("Your registered email address");

        g.insets = new Insets(0, 0, 4, 0);
        g.gridy = y++;
        form.add(UiUtil.fieldLabel("Username"), g);
        g.insets = new Insets(0, 0, 14, 0);
        g.gridy = y++;
        form.add(usernameField, g);

        g.insets = new Insets(0, 0, 4, 0);
        g.gridy = y++;
        form.add(UiUtil.fieldLabel("Password"), g);
        g.insets = new Insets(0, 0, 14, 0);
        g.gridy = y++;
        form.add(passwordField, g);

        donorRadio = new JRadioButton("Donor", true);
        recipientRadio = new JRadioButton("Recipient");
        ButtonGroup group = new ButtonGroup();
        group.add(donorRadio);
        group.add(recipientRadio);
        JPanel roles = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        roles.setOpaque(false);
        donorRadio.setOpaque(false);
        recipientRadio.setOpaque(false);
        donorRadio.setBorder(new EmptyBorder(0, 0, 0, 22));
        roles.add(donorRadio);
        roles.add(recipientRadio);

        g.insets = new Insets(0, 0, 4, 0);
        g.gridy = y++;
        form.add(UiUtil.fieldLabel("Login as"), g);
        g.insets = new Insets(0, 0, 8, 0);
        g.gridy = y++;
        form.add(roles, g);

        statusLabel = new JLabel(" ");
        statusLabel.setFont(UiUtil.font(Font.PLAIN, 12f));
        statusLabel.setForeground(UiUtil.RED);
        statusLabel.setVerticalAlignment(SwingConstants.TOP);
        statusLabel.setPreferredSize(new Dimension(10, 36));
        g.insets = new Insets(0, 0, 8, 0);
        g.gridy = y++;
        form.add(statusLabel, g);

        JButton loginButton = UiUtil.primary("Login");
        loginButton.setFont(UiUtil.font(Font.BOLD, 14f));
        defaultButton = loginButton;
        g.insets = new Insets(0, 0, 10, 0);
        g.gridy = y++;
        form.add(loginButton, g);

        JPanel secondary = new JPanel(new GridLayout(1, 2, 10, 0));
        secondary.setOpaque(false);
        JButton registerButton = UiUtil.secondary("Create account");
        JButton cancelButton = UiUtil.secondary("Cancel");
        secondary.add(registerButton);
        secondary.add(cancelButton);
        g.insets = new Insets(0, 0, 0, 0);
        g.gridy = y++;
        form.add(secondary, g);

        loginButton.addActionListener(e -> handleLogin());
        registerButton.addActionListener(e -> {
            new RegisterForm();
            dispose();
        });
        cancelButton.addActionListener(e -> System.exit(0));

        right.add(form, new GridBagConstraints());
        return right;
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());     // passwords are never trimmed
        String selectedRole = donorRadio.isSelected() ? Session.DONOR : Session.RECIPIENT;

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter both username and password.");
            return;
        }

        try (Connection c = DBConfig.getConnection()) {
            UserDAO.AuthResult result = UserDAO.authenticate(c, username, password, selectedRole);

            if (result.status == UserDAO.AuthResult.BAD_CREDENTIALS) {
                showError("Incorrect username or password. Please try again.");
                passwordField.setText("");
            } else if (result.status == UserDAO.AuthResult.WRONG_ROLE) {
                String actual = Session.DONOR.equals(result.role) ? "Donor" : "Recipient";
                showError("This account is registered as a " + actual + ". Please choose '" + actual + "' above.");
            } else {
                Session.start(result.userId, result.role, result.institution);
                if (Session.DONOR.equals(result.role)) {
                    new DonorDashboard();
                } else {
                    new RecipientDashboard();
                }
                dispose();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            showError(UiUtil.friendlyMessage(ex));
        }
    }

    private void showError(String message) {
        statusLabel.setForeground(UiUtil.RED);
        statusLabel.setText("<html><div style='width:250px'>" + message + "</div></html>");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginForm::new);
    }
}
