package registration;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Donor screen (FR3, FR4 queue, FR7). Only opens for a logged-in DONOR session (NFR3).
 * All data access goes through the DAO classes; claim/accept rules live in ClaimService.
 */
public class DonorDashboard extends JFrame {

    private final int userId;
    private UserDAO.Profile profile;

    private DefaultTableModel listingModel, requestModel, historyModel;
    private JTable listingTable, requestTable, historyTable;
    private JLabel listingStatusLabel, requestStatusLabel, welcomeLabel;

    private JComboBox<String> foodTypeBox, unitBox;
    private JTextField foodNameField, quantityField, hoursField;
    private JCheckBox cityOnlyBox;

    private JLabel profNameLabel, profIdLabel, profTypeLabel, profPhoneLabel, profAddressLabel, profCityLabel;
    private JLabel activeValue, pendingValue, donatedValue, handoverValue;

    private javax.swing.Timer countdownTimer;

    public DonorDashboard() {
        UiUtil.installTheme();
        userId = Session.getUserId();
        if (!Session.hasRole(Session.DONOR)) {          // session / role guard
            UiUtil.showWarn(null, "Please log in as a Donor to open this dashboard.");
            dispose();
            new LoginForm();
            return;
        }

        setTitle("Donor Dashboard - Food Redistribution Management");
        setSize(1100, 760);
        setMinimumSize(new Dimension(980, 640));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        welcomeLabel = new JLabel("Welcome, " + nameOrDefault(Session.getInstitution()));
        JButton headerLogout = UiUtil.onHeader("Log Out");
        headerLogout.addActionListener(e -> logout());
        add(UiUtil.appHeader(welcomeLabel, "Share surplus food with people who need it", "DONOR PORTAL", headerLogout),
                BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("My Active Listings", buildListingsTab());
        tabs.addTab("New Donation & Requests", buildDonationTab());
        tabs.addTab("Profile & Metrics", buildProfileTab());
        add(tabs, BorderLayout.CENTER);

        refreshAll();

        countdownTimer = new javax.swing.Timer(1000, e -> tickCountdown());
        countdownTimer.start();
        setVisible(true);
    }

    // =================================================================== UI
    private JPanel buildListingsTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(18, 22, 12, 22));
        panel.add(UiUtil.sectionTitle("Your listings (available, or waiting for pickup)"), BorderLayout.NORTH);

        listingModel = UiUtil.readOnlyModel("Listing ID", "Food Name", "Food Type", "Quantity", "Unit", "Expires At", "Time Left", "Status", "Accepted By");
        listingTable = new JTable(listingModel);
        UiUtil.styleTable(listingTable, 30);
        listingTable.getColumnModel().getColumn(5).setCellRenderer(UiUtil.TIMESTAMP_RENDERER);
        panel.add(new JScrollPane(listingTable), BorderLayout.CENTER);

        JButton refresh = UiUtil.secondary("Refresh");
        JButton edit = UiUtil.primary("Edit Selected");
        JButton cancel = UiUtil.danger("Cancel Selected Listing");
        JButton confirm = UiUtil.primary("Confirm Handover (OTP)");
        JButton release = UiUtil.neutral("Release Pickup");
        refresh.addActionListener(e -> refreshAll());
        edit.addActionListener(e -> editSelectedListing());
        cancel.addActionListener(e -> cancelSelectedListing());
        confirm.addActionListener(e -> confirmSelectedHandover());
        release.addActionListener(e -> releaseSelectedPickup());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttons.add(refresh);
        buttons.add(edit);
        buttons.add(cancel);
        buttons.add(release);
        buttons.add(confirm);

        listingStatusLabel = UiUtil.statusLine();
        JPanel south = new JPanel(new BorderLayout());
        south.setBorder(BorderFactory.createEmptyBorder(6, 0, 0, 0));
        south.add(listingStatusLabel, BorderLayout.WEST);
        south.add(buttons, BorderLayout.EAST);
        panel.add(south, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel buildDonationTab() {
        JPanel page = new JPanel(new BorderLayout(0, 16));
        page.setBorder(BorderFactory.createEmptyBorder(18, 22, 16, 22));

        // ---- publish form (card across the top)
        foodNameField = new JTextField();
        foodTypeBox = new JComboBox<>(UiUtil.FOOD_TYPES);
        quantityField = new JTextField();
        unitBox = new JComboBox<>(UiUtil.UNITS);
        hoursField = new JTextField();

        JPanel quantityRow = new JPanel(new GridLayout(1, 2, 8, 0));
        quantityRow.setOpaque(false);
        quantityRow.add(quantityField);
        quantityRow.add(unitBox);

        JButton publish = UiUtil.primary("Publish Donation");
        publish.setFont(UiUtil.font(Font.BOLD, 14f));
        publish.addActionListener(e -> publishDonation());

        JPanel row = new JPanel(new GridBagLayout());
        row.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.gridy = 0;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.anchor = GridBagConstraints.SOUTH;
        g.insets = new Insets(0, 0, 0, 14);
        addCell(row, g, 0, 3.0, "Food name (e.g. Vegetable Biryani)", foodNameField);
        addCell(row, g, 1, 1.2, "Food type", foodTypeBox);
        addCell(row, g, 2, 2.4, "Quantity & unit", quantityRow);
        addCell(row, g, 3, 1.3, "Expires in (hours, 1-720)", hoursField);
        g.gridx = 4;
        g.weightx = 1.2;
        g.insets = new Insets(0, 0, 0, 0);
        JPanel btnBox = new JPanel(new BorderLayout(0, 4));
        btnBox.setOpaque(false);
        btnBox.add(UiUtil.fieldLabel(" "), BorderLayout.NORTH);
        btnBox.add(publish, BorderLayout.CENTER);
        row.add(btnBox, g);

        UiUtil.Card formCard = new UiUtil.Card(new BorderLayout(0, 12));
        formCard.setBorder(BorderFactory.createEmptyBorder(14, 20, 18, 20));
        JPanel formHead = new JPanel(new BorderLayout(12, 0));
        formHead.setOpaque(false);
        formHead.add(UiUtil.sectionTitle("Post surplus food"), BorderLayout.WEST);
        JLabel hint = UiUtil.statusLine();
        hint.setText("A recipient who accepts it will come to you and give you an OTP.");
        formHead.add(hint, BorderLayout.CENTER);
        formCard.add(formHead, BorderLayout.NORTH);
        formCard.add(row, BorderLayout.CENTER);
        page.add(formCard, BorderLayout.NORTH);

        // ---- open requests queue (right)
        JPanel queue = new JPanel(new BorderLayout(6, 10));
        cityOnlyBox = new JCheckBox("My city only", true);
        cityOnlyBox.setOpaque(false);
        cityOnlyBox.addActionListener(e -> refreshRequestsOnly());
        JPanel queueHead = new JPanel(new BorderLayout());
        queueHead.add(UiUtil.sectionTitle("Open requests from recipients (most urgent first)"), BorderLayout.WEST);
        queueHead.add(cityOnlyBox, BorderLayout.EAST);
        queue.add(queueHead, BorderLayout.NORTH);

        requestModel = UiUtil.readOnlyModel("Request ID", "Institution", "City", "Food Name Needed", "Food Type", "Servings", "Urgency", "Posted");
        requestTable = new JTable(requestModel);
        UiUtil.styleTable(requestTable, 30);
        requestTable.getColumnModel().getColumn(7).setCellRenderer(UiUtil.TIMESTAMP_RENDERER);
        queue.add(new JScrollPane(requestTable), BorderLayout.CENTER);

        JButton accept = UiUtil.primary("Accept Selected Request");
        accept.addActionListener(e -> acceptSelectedRequest());
        JButton refresh = UiUtil.secondary("Refresh Requests");
        refresh.addActionListener(e -> refreshRequestsOnly());
        requestStatusLabel = UiUtil.statusLine();

        JPanel qButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        qButtons.add(refresh);
        qButtons.add(accept);
        JPanel qSouth = new JPanel(new BorderLayout());
        qSouth.setBorder(BorderFactory.createEmptyBorder(6, 0, 0, 0));
        qSouth.add(requestStatusLabel, BorderLayout.WEST);
        qSouth.add(qButtons, BorderLayout.EAST);
        queue.add(qSouth, BorderLayout.SOUTH);

        page.add(queue, BorderLayout.CENTER);
        return page;
    }

    private static void addCell(JPanel row, GridBagConstraints g, int x, double weight, String caption, JComponent comp) {
        JPanel box = new JPanel(new BorderLayout(0, 4));
        box.setOpaque(false);
        box.add(UiUtil.fieldLabel(caption), BorderLayout.NORTH);
        box.add(comp, BorderLayout.CENTER);
        g.gridx = x;
        g.weightx = weight;
        row.add(box, g);
    }

    private JPanel buildProfileTab() {
        JPanel panel = new JPanel(new BorderLayout(0, 16));
        panel.setBorder(BorderFactory.createEmptyBorder(18, 22, 16, 22));

        // ---- registry card
        profNameLabel = new JLabel();
        profIdLabel = new JLabel();
        profTypeLabel = new JLabel();
        profPhoneLabel = new JLabel();
        profAddressLabel = new JLabel();
        profCityLabel = new JLabel();
        JPanel lines = new JPanel(new GridLayout(0, 2, 20, 6));
        lines.setOpaque(false);
        profNameLabel.setFont(UiUtil.font(Font.BOLD, 17f));
        profNameLabel.setForeground(UiUtil.ORANGE_DARK);
        for (JLabel l : new JLabel[]{profIdLabel, profTypeLabel, profPhoneLabel, profCityLabel, profAddressLabel}) {
            l.setFont(UiUtil.font(Font.PLAIN, 13f));
            lines.add(l);
        }
        JButton editProfile = UiUtil.primary("Edit Profile");
        editProfile.addActionListener(e -> {
            if (ProfileDialog.edit(this, userId, false)) {
                refreshAll();
                UiUtil.showInfo(this, "Profile updated.");
            }
        });
        UiUtil.Card card = new UiUtil.Card(new BorderLayout(0, 10), UiUtil.ORANGE);
        card.setBorder(BorderFactory.createEmptyBorder(16, 24, 16, 20));
        JPanel cardTop = new JPanel(new BorderLayout(10, 0));
        cardTop.setOpaque(false);
        JLabel cap = UiUtil.statusLine();
        cap.setText("DONOR REGISTRY CARD");
        JPanel nameBox = new JPanel(new GridLayout(2, 1, 0, 2));
        nameBox.setOpaque(false);
        nameBox.add(cap);
        nameBox.add(profNameLabel);
        cardTop.add(nameBox, BorderLayout.CENTER);
        cardTop.add(editProfile, BorderLayout.EAST);
        card.add(cardTop, BorderLayout.NORTH);
        card.add(lines, BorderLayout.CENTER);

        // ---- metrics
        JPanel metrics = new JPanel(new GridLayout(1, 4, 14, 0));
        metrics.setOpaque(false);
        activeValue = UiUtil.metricCard(metrics, "ACTIVE LISTINGS", UiUtil.ORANGE);
        pendingValue = UiUtil.metricCard(metrics, "PENDING REQUESTS", new Color(0xFFB74D));
        donatedValue = UiUtil.metricCard(metrics, "TOTAL DONATED", UiUtil.ORANGE_DARK);
        handoverValue = UiUtil.metricCard(metrics, "COMPLETED HANDOVERS", new Color(0xFFCC80));

        JPanel header = new JPanel(new BorderLayout(0, 14));
        header.setOpaque(false);
        header.add(card, BorderLayout.NORTH);
        header.add(metrics, BorderLayout.CENTER);
        panel.add(header, BorderLayout.NORTH);

        JPanel history = new JPanel(new BorderLayout(5, 8));
        history.add(UiUtil.sectionTitle("Donation history (all listings)"), BorderLayout.NORTH);
        historyModel = UiUtil.readOnlyModel("Listing ID", "Food Name", "Food Type", "Quantity", "Unit", "Status", "Claimed By", "Expiry");
        historyTable = new JTable(historyModel);
        UiUtil.styleTable(historyTable, 28);
        historyTable.getColumnModel().getColumn(7).setCellRenderer(UiUtil.TIMESTAMP_RENDERER);
        history.add(new JScrollPane(historyTable), BorderLayout.CENTER);
        panel.add(history, BorderLayout.CENTER);
        return panel;
    }

    // ============================================================== loading
    /** One database connection is used for the whole refresh instead of one per query. */
    private void refreshAll() {
        try (Connection c = DBConfig.getConnection()) {
            DonationDAO.expireOld(c);
            profile = UserDAO.getProfile(c, userId);
            showProfile();
            fillListings(DonationDAO.listActive(c, userId));
            fillRequests(RequestDAO.listOpenForDonor(c, requestCity()));
            fillHistory(DonationDAO.listHistory(c, userId));
            showMetrics(DonationDAO.metrics(c, userId));
            stamp(listingStatusLabel, listingModel.getRowCount() + " open listing(s)");
        } catch (SQLException ex) {
            UiUtil.showDbError(this, ex);
        }
    }

    private void refreshRequestsOnly() {
        try (Connection c = DBConfig.getConnection()) {
            fillRequests(RequestDAO.listOpenForDonor(c, requestCity()));
        } catch (SQLException ex) {
            UiUtil.showDbError(this, ex);
        }
    }

    private String requestCity() {
        boolean localOnly = cityOnlyBox == null || cityOnlyBox.isSelected();
        return (localOnly && profile != null && profile.city != null && !profile.city.isEmpty()) ? profile.city : null;
    }

    private void showProfile() {
        if (profile == null) return;
        welcomeLabel.setText("Welcome, " + nameOrDefault(profile.institution));
        profNameLabel.setText(profile.institution);
        profIdLabel.setText(kv("Account ID", userId + "   \u2022   " + profile.username));
        profTypeLabel.setText(kv("Entity Type", profile.donorType == null ? "N/A" : profile.donorType));
        profPhoneLabel.setText(kv("Contact Phone", profile.phone));
        profCityLabel.setText(kv("City", profile.city));
        profAddressLabel.setText(kv("Address", profile.address));
    }

    /** "Label: value" with a muted label, as small HTML. */
    private static String kv(String key, Object value) {
        return "<html><span style='color:#8D7B6B'>" + key + ":</span>&nbsp; " + value + "</html>";
    }

    private void fillListings(List<Object[]> rows) {
        listingModel.setRowCount(0);
        for (Object[] r : rows) {
            Object acceptedBy = (r[7] == null || r[7].toString().trim().isEmpty()) ? "-" : r[7];
            listingModel.addRow(new Object[]{r[0], r[1], r[2], r[3], r[4], r[5], UiUtil.formatRemaining((Timestamp) r[5]), r[6], acceptedBy});
        }
    }

    private void fillRequests(List<Object[]> rows) {
        requestModel.setRowCount(0);
        for (Object[] r : rows) requestModel.addRow(r);
        stamp(requestStatusLabel, rows.size() + " open request(s)");
    }

    private void fillHistory(List<Object[]> rows) {
        historyModel.setRowCount(0);
        for (Object[] r : rows) {
            Object claimedBy = (r[6] == null || r[6].toString().trim().isEmpty()) ? "-" : r[6];
            historyModel.addRow(new Object[]{r[0], r[1], r[2], r[3], r[4], r[5], claimedBy, r[7]});
        }
    }

    private void showMetrics(DonationDAO.DonorMetrics m) {
        activeValue.setText(String.valueOf(m.activeListings));
        pendingValue.setText(String.valueOf(m.pendingRequests));
        donatedValue.setText(m.totalServings + " servings / " + m.totalKg + " kg");
        handoverValue.setText(String.valueOf(m.completedHandovers));
    }

    private void stamp(JLabel label, String text) {
        label.setText(text + "   \u2022   updated " + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
    }

    /** Live time-to-expiry counter, refreshed every second without touching the database. */
    private void tickCountdown() {
        for (int r = 0; r < listingModel.getRowCount(); r++) {
            listingModel.setValueAt(UiUtil.formatRemaining((Timestamp) listingModel.getValueAt(r, 5)), r, 6);
        }
    }

    // ============================================================== actions
    private static final class ListingInput {
        String foodName, foodType, unit;
        int quantity, hours;
    }

    /** Validates the listing fields; shows a plain-language message and returns null when something is wrong. */
    private ListingInput readListing(String nameText, Object type, String qtyText, Object unit, String hoursText) {
        String name = nameText == null ? "" : nameText.trim();
        if (name.isEmpty()) {
            UiUtil.showError(this, "Please enter the name of the food (for example: Vegetable Biryani).");
            return null;
        }
        if (name.length() > 100) {
            UiUtil.showError(this, "The food name is too long. Please keep it within 100 characters.");
            return null;
        }
        Integer qty = UiUtil.parsePositiveInt(qtyText);
        if (qty == null || qty > 100000) {
            UiUtil.showError(this, "Quantity must be a whole number between 1 and 100000.");
            return null;
        }
        Integer hrs = UiUtil.parsePositiveInt(hoursText);
        if (hrs == null || hrs > 720) {
            UiUtil.showError(this, "Expiry time must be a whole number of hours between 1 and 720.");
            return null;
        }
        ListingInput in = new ListingInput();
        in.foodName = name;
        in.foodType = (String) type;
        in.unit = (String) unit;
        in.quantity = qty;
        in.hours = hrs;
        return in;
    }

    private void publishDonation() {
        ListingInput in = readListing(foodNameField.getText(), foodTypeBox.getSelectedItem(), quantityField.getText(),
                unitBox.getSelectedItem(), hoursField.getText());
        if (in == null) return;
        try (Connection c = DBConfig.getConnection()) {
            DonationDAO.create(c, userId, in.foodName, in.foodType, in.quantity, in.unit, in.hours);
            foodNameField.setText("");
            quantityField.setText("");
            hoursField.setText("");
            refreshAll();
            UiUtil.showInfo(this, "Your donation is now live. A recipient who accepts it will come to collect it.");
        } catch (SQLException ex) {
            UiUtil.showDbError(this, ex);
        }
    }

    private void editSelectedListing() {
        int row = listingTable.getSelectedRow();
        if (row < 0) {
            UiUtil.showWarn(this, "Please select a listing to edit.");
            return;
        }
        int listingId = (Integer) listingModel.getValueAt(row, 0);
        String name = (String) listingModel.getValueAt(row, 1);
        String type = (String) listingModel.getValueAt(row, 2);
        int qty = (Integer) listingModel.getValueAt(row, 3);
        String unit = (String) listingModel.getValueAt(row, 4);
        long secondsLeft = ((Timestamp) listingModel.getValueAt(row, 5)).getTime() - System.currentTimeMillis();
        int hoursLeft = (int) Math.max(1, Math.ceil(secondsLeft / 3600000.0));

        JTextField nameField = new JTextField(name);
        JComboBox<String> typeBox = new JComboBox<>(UiUtil.FOOD_TYPES);
        typeBox.setSelectedItem(type);
        JTextField qtyField = new JTextField(String.valueOf(qty));
        JComboBox<String> unitChoice = new JComboBox<>(UiUtil.UNITS);
        unitChoice.setSelectedItem(unit);
        JTextField hrsField = new JTextField(String.valueOf(hoursLeft));

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new JLabel("Food Name:"));
        form.add(nameField);
        form.add(new JLabel("Food Type:"));
        form.add(typeBox);
        form.add(new JLabel("Quantity:"));
        form.add(qtyField);
        form.add(new JLabel("Quantity Unit:"));
        form.add(unitChoice);
        form.add(new JLabel("Expires in (hours from now):"));
        form.add(hrsField);

        ListingInput in;
        while (true) {
            int choice = JOptionPane.showConfirmDialog(this, form, "Edit Listing #" + listingId,
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (choice != JOptionPane.OK_OPTION) return;
            in = readListing(nameField.getText(), typeBox.getSelectedItem(), qtyField.getText(), unitChoice.getSelectedItem(), hrsField.getText());
            if (in != null) break;
        }

        try (Connection c = DBConfig.getConnection()) {
            int changed = DonationDAO.update(c, listingId, userId, in.foodName, in.foodType, in.quantity, in.unit, in.hours);
            if (changed == 0) {
                UiUtil.showWarn(this, "This listing can no longer be edited because it was accepted, claimed, cancelled or has expired.");
            } else {
                UiUtil.showInfo(this, "Listing updated.");
            }
            refreshAll();
        } catch (SQLException ex) {
            UiUtil.showDbError(this, ex);
        }
    }

    private void cancelSelectedListing() {
        int row = listingTable.getSelectedRow();
        if (row < 0) {
            UiUtil.showWarn(this, "Please select a listing to cancel.");
            return;
        }
        int listingId = (Integer) listingModel.getValueAt(row, 0);
        if (!UiUtil.confirm(this, "Withdraw listing #" + listingId + "? Recipients will no longer be able to claim it.")) return;
        try (Connection c = DBConfig.getConnection()) {
            int changed = DonationDAO.cancel(c, listingId, userId);
            if (changed == 0) {
                UiUtil.showWarn(this, "This listing was already accepted or closed, so it cannot be cancelled. If a recipient is waiting, use Release Pickup.");
            }
            refreshAll();
        } catch (SQLException ex) {
            UiUtil.showDbError(this, ex);
        }
    }

    /** Donor types the OTP told by the recipient; only then does the donation become CLAIMED. */
    private void confirmSelectedHandover() {
        int row = listingTable.getSelectedRow();
        if (row < 0) {
            UiUtil.showWarn(this, "Please select a pending listing first.");
            return;
        }
        if (!"PENDING".equals(listingModel.getValueAt(row, 7))) {
            UiUtil.showWarn(this, "Only listings with status PENDING (accepted by a recipient) can be confirmed.");
            return;
        }
        int listingId = (Integer) listingModel.getValueAt(row, 0);
        String who = String.valueOf(listingModel.getValueAt(row, 8));
        String otp = JOptionPane.showInputDialog(this,
                "Ask " + who + " for their 6-digit pickup OTP and enter it here:",
                "Confirm Handover - Listing #" + listingId, JOptionPane.PLAIN_MESSAGE);
        if (otp == null) return;      // cancelled

        ClaimService.Result result = ClaimService.confirmHandover(listingId, otp);
        if (result.success) UiUtil.showInfo(this, result.message); else UiUtil.showWarn(this, result.message);
        refreshAll();
    }

    /** Donor gives up a waiting pickup (for example the recipient never came). */
    private void releaseSelectedPickup() {
        int row = listingTable.getSelectedRow();
        if (row < 0) {
            UiUtil.showWarn(this, "Please select a pending listing first.");
            return;
        }
        if (!"PENDING".equals(listingModel.getValueAt(row, 7))) {
            UiUtil.showWarn(this, "Only listings with status PENDING can be released.");
            return;
        }
        int listingId = (Integer) listingModel.getValueAt(row, 0);
        if (!UiUtil.confirm(this, "Cancel the waiting pickup for listing #" + listingId + "?\n"
                + "The recipient's OTP will stop working.")) return;

        ClaimService.Result result = ClaimService.releasePickup(listingId);
        if (result.success) UiUtil.showInfo(this, result.message); else UiUtil.showWarn(this, result.message);
        refreshAll();
    }

    private void acceptSelectedRequest() {
        int row = requestTable.getSelectedRow();
        if (row < 0) {
            UiUtil.showWarn(this, "Please select a request from the table first.");
            return;
        }
        int requestId = (Integer) requestModel.getValueAt(row, 0);
        String who = String.valueOf(requestModel.getValueAt(row, 1));
        String what = String.valueOf(requestModel.getValueAt(row, 3));
        if (!UiUtil.confirm(this, "Accept this request from " + who + " for " + what + " and commit to handing it over?\nIt stays PENDING until you enter the recipient's OTP.")) return;

        ClaimService.Result result = ClaimService.fulfillRequest(requestId);
        if (result.success) UiUtil.showInfo(this, result.message); else UiUtil.showWarn(this, result.message);
        refreshAll();
    }

    private void logout() {
        Session.end();           // revoke access
        dispose();
        new LoginForm();
    }

    @Override
    public void dispose() {
        if (countdownTimer != null) countdownTimer.stop();
        super.dispose();
    }

    private static String nameOrDefault(String name) {
        return (name == null || name.isEmpty()) ? "Donor Account" : name.toUpperCase();
    }
}
