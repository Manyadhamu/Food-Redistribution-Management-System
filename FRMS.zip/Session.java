package registration;

/**
 * Holds the logged-in user (FR1 - session management, NFR3 - role enforcement).
 * Dashboards check this before opening, and logout clears it, so a closed session
 * cannot be used to reach a dashboard again.
 */
public final class Session {

    public static final String DONOR = "DONOR";
    public static final String RECIPIENT = "RECIPIENT";

    private static int userId = -1;
    private static String role;
    private static String institution;

    private Session() { }

    public static synchronized void start(int id, String userRole, String institutionName) {
        userId = id;
        role = userRole;
        institution = institutionName;
    }

    public static synchronized void end() {
        userId = -1;
        role = null;
        institution = null;
    }

    public static synchronized boolean isActive() { return userId > 0 && role != null; }

    public static synchronized boolean hasRole(String expectedRole) {
        return isActive() && role.equals(expectedRole);
    }

    public static synchronized int getUserId() { return userId; }

    public static synchronized String getRole() { return role; }

    public static synchronized String getInstitution() { return institution; }
}
