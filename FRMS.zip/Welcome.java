package registration;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;


public class Welcome extends JFrame implements ActionListener {
    private JLabel mainTitleLabel;
    private JLabel subTitleLabel;
    private JButton loginButton;
    private JButton registerButton;
    private JButton exitButton;

    public Welcome() {
        UiUtil.installTheme();
        setTitle("Food Redistribution Management System");
        setSize(760, 480);
        setMinimumSize(new Dimension(680, 440));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));

        add(buildHero());
        add(buildActions());
        setVisible(true);
    }

    private JPanel buildHero() {
        JPanel hero = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, UiUtil.ORANGE_LIGHT, getWidth(), getHeight(), UiUtil.ORANGE_DARK));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 30));
                g2.fill(new Ellipse2D.Float(-90, getHeight() - 220, 320, 320));
                g2.fill(new Ellipse2D.Float(getWidth() - 150, -90, 250, 250));
                g2.dispose();
            }
        };
        hero.setBorder(new EmptyBorder(30, 36, 30, 36));
        JPanel stack = new JPanel();
        stack.setOpaque(false);
        stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel(new UiUtil.LogoIcon(72, true));
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainTitleLabel = new JLabel("FOOD REDISTRIBUTION");
        mainTitleLabel.setFont(UiUtil.font(Font.BOLD, 26f));
        mainTitleLabel.setForeground(Color.WHITE);
        mainTitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        subTitleLabel = new JLabel("MANAGEMENT SYSTEM");
        subTitleLabel.setFont(UiUtil.font(Font.PLAIN, 15f));
        subTitleLabel.setForeground(new Color(255, 255, 255, 225));
        subTitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        stack.add(logo);
        stack.add(Box.createVerticalStrut(22));
        stack.add(mainTitleLabel);
        stack.add(Box.createVerticalStrut(4));
        stack.add(subTitleLabel);
        hero.add(stack);
        return hero;
    }

    private JPanel buildActions() {
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(Color.WHITE);
        right.setBorder(new EmptyBorder(30, 48, 30, 48));

        JPanel col = new JPanel(new GridLayout(0, 1, 0, 12));
        col.setOpaque(false);
        JLabel hello = new JLabel("Get started");
        hello.setFont(UiUtil.font(Font.BOLD, 26f));
        hello.setForeground(UiUtil.ORANGE_DARK);
        JLabel sub = UiUtil.statusLine();
        sub.setText("Log in or create an account to continue");
        col.add(hello);
        col.add(sub);

        loginButton = UiUtil.primary("Login to Account");
        loginButton.setFont(UiUtil.font(Font.BOLD, 14f));
        registerButton = UiUtil.secondary("Register New User");
        registerButton.setFont(UiUtil.font(Font.BOLD, 14f));
        exitButton = UiUtil.secondary("Exit");
        col.add(loginButton);
        col.add(registerButton);
        col.add(exitButton);

        loginButton.addActionListener(this);
        registerButton.addActionListener(this);
        exitButton.addActionListener(this);
        right.add(col);
        return right;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            new LoginForm();
            this.dispose();
        } else if (e.getSource() == registerButton) {
            new RegisterForm();
            this.dispose();
        } else if (e.getSource() == exitButton) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Welcome::new);
    }
}
